import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/queries.server-CBM6oKFJ.js
var _0002_ideathon_default = "-- IIC Ideathon · Venture Floor\n-- Shared event data (no user accounts). Rows are unowned and world-readable\n-- through public server functions; mutations that change the event are gated\n-- by an organizer session token.\n\ncreate table if not exists event_settings (\n  id integer primary key check (id = 1),\n  admin_password_hash text not null,\n  initial_amount integer not null default 1000,\n  min_investment integer not null default 1,\n  voting_open boolean not null default false,\n  deadline timestamptz,\n  event_name text not null default 'IIC Ideathon',\n  venue text not null default 'SDPK Hall, College of Engineering Adoor',\n  event_when text not null default '15 September 2026 · 9:00 AM – 12:30 PM',\n  updated_at timestamptz not null default now()\n);\n\ncreate table if not exists teams (\n  id serial primary key,\n  name text not null,\n  code text not null,\n  pitch text not null default '',\n  initial_balance integer not null,\n  created_at timestamptz not null default now()\n);\n\ncreate unique index if not exists teams_name_lower_idx on teams (lower(name));\ncreate unique index if not exists teams_code_idx on teams (code);\n\ncreate table if not exists submissions (\n  from_team_id integer primary key references teams(id) on delete cascade,\n  allocations jsonb not null default '[]'::jsonb,\n  remaining integer not null default 0,\n  submitted_at timestamptz not null default now()\n);\n\ncreate table if not exists admin_sessions (\n  token text primary key,\n  created_at timestamptz not null default now()\n);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_ideathon.sql": _0002_ideathon_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
var DEFAULT_PASSWORD = "admin123";
var DEMO_TEAMS = [
	{
		name: "Aether",
		pitch: "Low-cost air-quality mesh for campus hostels."
	},
	{
		name: "Circuit Breakers",
		pitch: "Smart energy trip system that saves lab equipment."
	},
	{
		name: "GreenShift",
		pitch: "Canteen food-waste to biogas, sized for CEA."
	},
	{
		name: "NexLab",
		pitch: "Offline AR lab manuals for first-year workshops."
	},
	{
		name: "PixelForge",
		pitch: "Exam proctoring that works without a cloud lock-in."
	},
	{
		name: "HydroLogic",
		pitch: "Acoustic leak detection for campus water lines."
	}
];
function hashPassword(password) {
	const salt = randomBytes(16).toString("hex");
	return `${salt}:${scryptSync(password, salt, 32).toString("hex")}`;
}
function verifyPassword(password, stored) {
	const [salt, hash] = stored.split(":");
	if (!salt || !hash) return false;
	const next = scryptSync(password, salt, 32);
	const prev = Buffer.from(hash, "hex");
	if (next.length !== prev.length) return false;
	return timingSafeEqual(next, prev);
}
function newCode() {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	let out = "";
	const bytes = randomBytes(4);
	for (let i = 0; i < 4; i += 1) out += alphabet[bytes[i] % 32];
	return out;
}
function toIso(value) {
	if (!value) return null;
	const d = value instanceof Date ? value : new Date(value);
	if (Number.isNaN(d.getTime())) return null;
	return d.toISOString();
}
function asAllocations(raw) {
	if (typeof raw === "string") try {
		raw = JSON.parse(raw);
	} catch {
		return [];
	}
	if (!Array.isArray(raw)) return [];
	return raw.map((item) => {
		if (!item || typeof item !== "object") return null;
		const rec = item;
		const toTeamId = Number(rec.toTeamId);
		const amount = Number(rec.amount);
		if (!Number.isInteger(toTeamId) || !Number.isInteger(amount)) return null;
		return {
			toTeamId,
			amount
		};
	}).filter((row) => row !== null && row.amount > 0);
}
function isUniqueViolation(error) {
	if (!error || typeof error !== "object") return false;
	const rec = error;
	if (rec.code === "23505") return true;
	return typeof rec.message === "string" && /unique/i.test(rec.message);
}
async function uniqueCode(sql, taken) {
	for (let i = 0; i < 24; i += 1) {
		const code = newCode();
		if (taken.has(code)) continue;
		if ((await sql`select code from teams where code = ${code}`).length === 0) {
			taken.add(code);
			return code;
		}
	}
	throw new Error("Could not allocate a team code. Try again.");
}
var readyPromise = null;
async function ensureReady(sql) {
	if ((await sql`select id from event_settings where id = 1`).length === 0) await sql.query(`insert into event_settings (id, admin_password_hash, initial_amount, voting_open)
       values (1, $1, 1000, true)
       on conflict (id) do nothing`, [hashPassword(DEFAULT_PASSWORD)]);
	if (((await sql`select count(*)::int as n from teams`)[0]?.n ?? 0) === 0) {
		const settings = await loadSettings(sql);
		const taken = /* @__PURE__ */ new Set();
		for (const team of DEMO_TEAMS) {
			const code = await uniqueCode(sql, taken);
			try {
				await sql.query(`insert into teams (name, code, pitch, initial_balance) values ($1, $2, $3, $4)`, [
					team.name,
					code,
					team.pitch,
					settings.initial_amount
				]);
			} catch (error) {
				if (!isUniqueViolation(error)) throw error;
			}
		}
	}
}
async function withDb(fn) {
	const sql = await getSql();
	readyPromise ??= ensureReady(sql).catch((error) => {
		readyPromise = null;
		throw error;
	});
	await readyPromise;
	return fn(sql);
}
async function loadSettings(sql) {
	const row = (await sql`
    select admin_password_hash, initial_amount, min_investment, voting_open,
           deadline, event_name, venue, event_when
    from event_settings where id = 1
  `)[0];
	if (!row) throw new Error("Event settings are missing.");
	return row;
}
function votingIsLive(settings, now = /* @__PURE__ */ new Date()) {
	if (!settings.voting_open) return false;
	const deadline = toIso(settings.deadline);
	if (!deadline) return true;
	return new Date(deadline).getTime() > now.getTime();
}
async function loadTeams(sql) {
	return sql`
    select id, name, code, pitch, initial_balance
    from teams
    order by lower(name) asc, id asc
  `;
}
async function loadSubmissions(sql) {
	return sql`
    select from_team_id, allocations, remaining, submitted_at
    from submissions
  `;
}
function buildLeaderboard(teams, submissions) {
	const nameById = new Map(teams.map((t) => [t.id, t.name]));
	const received = /* @__PURE__ */ new Map();
	for (const team of teams) received.set(team.id, {
		total: 0,
		investors: []
	});
	const votes = [];
	let totalInvested = 0;
	for (const sub of submissions) {
		const fromName = nameById.get(sub.from_team_id) ?? "Unknown";
		const stamp = toIso(sub.submitted_at) ?? (/* @__PURE__ */ new Date()).toISOString();
		for (const alloc of asAllocations(sub.allocations)) {
			totalInvested += alloc.amount;
			const bucket = received.get(alloc.toTeamId);
			if (bucket) {
				bucket.total += alloc.amount;
				bucket.investors.push({
					fromTeam: fromName,
					amount: alloc.amount
				});
			}
			votes.push({
				fromTeamId: sub.from_team_id,
				fromTeam: fromName,
				toTeamId: alloc.toTeamId,
				toTeam: nameById.get(alloc.toTeamId) ?? "Unknown",
				amount: alloc.amount,
				timestamp: stamp
			});
		}
	}
	const ranked = [...teams].map((team) => {
		const bucket = received.get(team.id) ?? {
			total: 0,
			investors: []
		};
		const investorCount = bucket.investors.length;
		return {
			id: team.id,
			name: team.name,
			pitch: team.pitch,
			received: bucket.total,
			investorCount,
			averageInvestment: investorCount === 0 ? 0 : Math.round(bucket.total / investorCount),
			rank: 0
		};
	}).sort((a, b) => {
		if (b.received !== a.received) return b.received - a.received;
		return a.name.localeCompare(b.name);
	});
	let lastReceived = Number.POSITIVE_INFINITY;
	let lastRank = 0;
	ranked.forEach((team, index) => {
		if (team.received < lastReceived) {
			lastRank = index + 1;
			lastReceived = team.received;
		}
		team.rank = lastRank;
	});
	const topInvestors = {};
	for (const team of teams) {
		const bucket = received.get(team.id);
		topInvestors[team.id] = (bucket?.investors ?? []).sort((a, b) => b.amount - a.amount).slice(0, 5);
	}
	votes.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
	return {
		leaderboard: ranked,
		votes,
		topInvestors,
		totalInvested
	};
}
function toPublicState(settings, teams, submissions) {
	const now = /* @__PURE__ */ new Date();
	const { leaderboard, totalInvested } = buildLeaderboard(teams, submissions);
	const totalInCirculation = teams.reduce((sum, t) => sum + t.initial_balance, 0);
	return {
		eventName: settings.event_name,
		venue: settings.venue,
		eventWhen: settings.event_when,
		votingOpen: settings.voting_open,
		votingLive: votingIsLive(settings, now),
		deadline: toIso(settings.deadline),
		initialAmount: settings.initial_amount,
		minInvestment: settings.min_investment,
		teamCount: teams.length,
		submittedCount: submissions.length,
		totalInCirculation,
		totalInvested,
		leaderboard,
		now: now.toISOString()
	};
}
async function loadPublicState() {
	return withDb(async (sql) => {
		const [settings, teams, submissions] = await Promise.all([
			loadSettings(sql),
			loadTeams(sql),
			loadSubmissions(sql)
		]);
		return toPublicState(settings, teams, submissions);
	});
}
async function loadAdminState(token) {
	return withDb(async (sql) => {
		await assertAdmin(sql, token);
		const [settings, teams, submissions] = await Promise.all([
			loadSettings(sql),
			loadTeams(sql),
			loadSubmissions(sql)
		]);
		const publicState = toPublicState(settings, teams, submissions);
		const { votes, topInvestors } = buildLeaderboard(teams, submissions);
		const subByTeam = new Map(submissions.map((s) => [s.from_team_id, s]));
		const adminTeams = teams.map((team) => {
			const sub = subByTeam.get(team.id);
			const invested = sub ? asAllocations(sub.allocations).reduce((sum, a) => sum + a.amount, 0) : 0;
			return {
				id: team.id,
				name: team.name,
				code: team.code,
				pitch: team.pitch,
				initialBalance: team.initial_balance,
				submitted: Boolean(sub),
				submittedAt: sub ? toIso(sub.submitted_at) : null,
				remaining: sub ? sub.remaining : team.initial_balance,
				invested
			};
		});
		return {
			...publicState,
			teams: adminTeams,
			votes,
			topInvestors
		};
	});
}
async function assertAdmin(sql, token) {
	if (!token) throw new Error("Organizer sign-in required.");
	if ((await sql`
    select token from admin_sessions
    where token = ${token}
      and created_at > now() - interval '12 hours'
  `).length === 0) throw new Error("Organizer session expired. Sign in again.");
}
async function loginAdmin(password) {
	return withDb(async (sql) => {
		if (!verifyPassword(password, (await loadSettings(sql)).admin_password_hash)) throw new Error("That password does not match.");
		await sql`delete from admin_sessions where created_at < now() - interval '12 hours'`;
		const token = randomBytes(32).toString("hex");
		await sql`insert into admin_sessions (token) values (${token})`;
		return { token };
	});
}
async function logoutAdmin(token) {
	return withDb(async (sql) => {
		if (token) await sql`delete from admin_sessions where token = ${token}`;
		return { ok: true };
	});
}
async function lookupTeam(nameOrCode) {
	return withDb(async (sql) => {
		const needle = nameOrCode.trim();
		if (!needle) throw new Error("Enter your team name or code.");
		const team = (await sql`
      select id, name, code, pitch, initial_balance
      from teams
      where lower(name) = lower(${needle}) or upper(code) = upper(${needle})
      limit 1
    `)[0];
		if (!team) throw new Error("No team matches that name or code.");
		const sub = (await sql`
      select from_team_id, allocations, remaining, submitted_at
      from submissions
      where from_team_id = ${team.id}
    `)[0];
		const nameById = new Map((await loadTeams(sql)).map((t) => [t.id, t.name]));
		const allocations = sub ? asAllocations(sub.allocations).map((a) => ({
			toTeamId: a.toTeamId,
			toTeamName: nameById.get(a.toTeamId) ?? "Unknown",
			amount: a.amount
		})) : [];
		return {
			team: {
				id: team.id,
				name: team.name,
				code: team.code,
				initialBalance: team.initial_balance
			},
			submitted: Boolean(sub),
			submittedAt: sub ? toIso(sub.submitted_at) : null,
			remaining: sub ? sub.remaining : team.initial_balance,
			allocations
		};
	});
}
async function submitAllocation(input) {
	return withDb(async (sql) => {
		const settings = await loadSettings(sql);
		if (!votingIsLive(settings)) throw new Error("Voting is closed.");
		const lookup = await lookupTeam(input.nameOrCode);
		if (lookup.submitted) throw new Error("This team has already submitted. Allocations are locked.");
		const teams = await loadTeams(sql);
		const teamIds = new Set(teams.map((t) => t.id));
		const cleaned = [];
		let spent = 0;
		for (const row of input.allocations) {
			const amount = Math.round(Number(row.amount) || 0);
			const toTeamId = Number(row.toTeamId);
			if (amount <= 0) continue;
			if (!Number.isInteger(amount)) throw new Error("Amounts must be whole rupees.");
			if (amount < settings.min_investment) throw new Error(`Minimum investment is ₹${settings.min_investment}.`);
			if (toTeamId === lookup.team.id) throw new Error("You cannot invest in your own idea.");
			if (!teamIds.has(toTeamId)) throw new Error("One of the selected teams no longer exists.");
			if (cleaned.some((a) => a.toTeamId === toTeamId)) throw new Error("Each team can only appear once in your allocation.");
			spent += amount;
			cleaned.push({
				toTeamId,
				amount
			});
		}
		if (cleaned.length === 0) throw new Error("Allocate at least ₹1 to another team.");
		if (spent > lookup.team.initialBalance) throw new Error("You cannot invest more than your purse.");
		const remaining = lookup.team.initialBalance - spent;
		try {
			await sql.query(`insert into submissions (from_team_id, allocations, remaining)
         values ($1, $2::jsonb, $3)`, [
				lookup.team.id,
				JSON.stringify(cleaned),
				remaining
			]);
		} catch (error) {
			if (isUniqueViolation(error)) throw new Error("This team has already submitted. Allocations are locked.");
			throw error;
		}
		return lookupTeam(input.nameOrCode);
	});
}
async function addTeam(token, input) {
	return withDb(async (sql) => {
		await assertAdmin(sql, token);
		const settings = await loadSettings(sql);
		const submissions = await loadSubmissions(sql);
		if (settings.voting_open && submissions.length > 0) throw new Error("Close voting before adding teams mid-round.");
		const name = input.name.trim();
		if (name.length < 2) throw new Error("Team name needs at least 2 characters.");
		if (name.length > 48) throw new Error("Keep team names under 48 characters.");
		const pitch = input.pitch.trim().slice(0, 180);
		const code = await uniqueCode(sql, /* @__PURE__ */ new Set());
		try {
			const id = (await sql`
        insert into teams (name, code, pitch, initial_balance)
        values (${name}, ${code}, ${pitch}, ${settings.initial_amount})
        returning id
      `)[0]?.id;
			if (!id) throw new Error("Could not add team.");
			return {
				id,
				name,
				code,
				pitch,
				initialBalance: settings.initial_amount,
				submitted: false,
				submittedAt: null,
				remaining: settings.initial_amount,
				invested: 0
			};
		} catch (error) {
			if (isUniqueViolation(error)) throw new Error("A team with that name already exists.");
			throw error;
		}
	});
}
async function updateTeam(token, input) {
	return withDb(async (sql) => {
		await assertAdmin(sql, token);
		const name = input.name.trim();
		if (name.length < 2) throw new Error("Team name needs at least 2 characters.");
		if (name.length > 48) throw new Error("Keep team names under 48 characters.");
		const pitch = input.pitch.trim().slice(0, 180);
		try {
			if (!(await sql`
        update teams set name = ${name}, pitch = ${pitch}
        where id = ${input.id}
        returning id
      `)[0]) throw new Error("Team not found.");
			return { ok: true };
		} catch (error) {
			if (isUniqueViolation(error)) throw new Error("A team with that name already exists.");
			throw error;
		}
	});
}
async function removeTeam(token, id) {
	return withDb(async (sql) => {
		await assertAdmin(sql, token);
		if ((await loadSubmissions(sql)).length > 0) throw new Error("Clear votes before removing a team.");
		await sql`delete from teams where id = ${id}`;
		return { ok: true };
	});
}
async function updateSettings(token, input) {
	return withDb(async (sql) => {
		await assertAdmin(sql, token);
		const initialAmount = Math.round(input.initialAmount);
		const minInvestment = Math.round(input.minInvestment);
		if (initialAmount < 10 || initialAmount > 1e6) throw new Error("Starting purse must be between ₹10 and ₹10,00,000.");
		if (minInvestment < 1 || minInvestment > initialAmount) throw new Error("Minimum investment must be at least ₹1 and within the purse.");
		const deadline = input.deadline?.trim() ? input.deadline : null;
		if (deadline && Number.isNaN(new Date(deadline).getTime())) throw new Error("Deadline is not a valid time.");
		await sql.query(`update event_settings
       set initial_amount = $1,
           min_investment = $2,
           deadline = $3,
           event_name = $4,
           venue = $5,
           event_when = $6,
           updated_at = now()
       where id = 1`, [
			initialAmount,
			minInvestment,
			deadline,
			input.eventName.trim() || "IIC Ideathon",
			input.venue.trim() || "SDPK Hall, College of Engineering Adoor",
			input.eventWhen.trim() || "15 September 2026 · 9:00 AM – 12:30 PM"
		]);
		if (input.applyAmountToTeams) {
			if ((await loadSubmissions(sql)).length > 0) throw new Error("Clear votes before changing every team's purse.");
			await sql`update teams set initial_balance = ${initialAmount}`;
		}
		return { ok: true };
	});
}
async function setVotingOpen(token, open) {
	return withDb(async (sql) => {
		await assertAdmin(sql, token);
		const teams = await loadTeams(sql);
		if (open && teams.length < 2) throw new Error("Add at least two teams before opening the floor.");
		await sql`update event_settings set voting_open = ${open}, updated_at = now() where id = 1`;
		return {
			ok: true,
			votingOpen: open
		};
	});
}
async function clearVotes(token) {
	return withDb(async (sql) => {
		await assertAdmin(sql, token);
		await sql`delete from submissions`;
		return { ok: true };
	});
}
async function changePassword(token, input) {
	return withDb(async (sql) => {
		await assertAdmin(sql, token);
		const settings = await loadSettings(sql);
		if (!verifyPassword(input.current, settings.admin_password_hash)) throw new Error("Current password is incorrect.");
		if (input.next.trim().length < 6) throw new Error("New password must be at least 6 characters.");
		await sql`update event_settings set admin_password_hash = ${hashPassword(input.next.trim())}, updated_at = now() where id = 1`;
		await sql`delete from admin_sessions where token <> ${token}`;
		return { ok: true };
	});
}
//#endregion
export { addTeam, changePassword, clearVotes, loadAdminState, loadPublicState, loginAdmin, logoutAdmin, lookupTeam, removeTeam, setVotingOpen, submitAllocation, updateSettings, updateTeam };
