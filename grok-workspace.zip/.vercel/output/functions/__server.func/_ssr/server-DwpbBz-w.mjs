import { o as __toESM } from "../_runtime.mjs";
import { S as require_react, x as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as object, i as number, n as boolean, o as string, t as array } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-DwpbBz-w.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatRupee(value) {
	return new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		maximumFractionDigits: 0
	}).format(Math.round(value));
}
function formatInt(value) {
	return new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(Math.round(value));
}
function parseRupeeInput(raw) {
	const digits = raw.replace(/[^\d]/g, "");
	if (!digits) return 0;
	const n = Number.parseInt(digits, 10);
	return Number.isFinite(n) ? n : 0;
}
function downloadCsv(filename, rows) {
	const body = rows.map((row) => row.map((cell) => {
		const value = cell ?? "";
		if (/[",\n]/.test(value)) return `"${value.replace(/"/g, "\"\"")}"`;
		return value;
	}).join(",")).join("\n");
	const blob = new Blob([body], { type: "text/csv;charset=utf-8;" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function isoToLocal(iso) {
	if (!iso) return "—";
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return "—";
	return new Intl.DateTimeFormat("en-IN", {
		dateStyle: "medium",
		timeStyle: "short"
	}).format(d);
}
function partsUntil(deadline, nowMs) {
	const end = new Date(deadline).getTime();
	const diff = Math.max(0, end - nowMs);
	const totalSeconds = Math.floor(diff / 1e3);
	return {
		hours: Math.floor(totalSeconds / 3600),
		minutes: Math.floor(totalSeconds % 3600 / 60),
		seconds: totalSeconds % 60,
		expired: diff <= 0
	};
}
function pad(n) {
	return String(n).padStart(2, "0");
}
function Countdown({ deadline, className }) {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		if (!deadline) return;
		const id = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(id);
	}, [deadline]);
	if (!deadline) return null;
	const { hours, minutes, seconds, expired } = partsUntil(deadline, now);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs uppercase tracking-[0.18em] text-muted-foreground",
			children: expired ? "Deadline passed" : "Closes in"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-2xl tabular-nums tracking-tight text-foreground",
			children: expired ? "00:00:00" : `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`
		})]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var tokenSchema = object({ token: string() });
var allocationSchema = object({
	toTeamId: number().int(),
	amount: number().int()
});
var getPublicState = createServerFn({ method: "GET" }).handler(createSsrRpc("eaf634d561198a3cf7f34aabceb5fb2026530b179b76ef7435477fe5bbb31878"));
var getAdminState = createServerFn({ method: "POST" }).validator(tokenSchema).handler(createSsrRpc("731dd655d1a98dad530a0cf169789cb93b68d0415559453e6303794305df5063"));
var adminLogin = createServerFn({ method: "POST" }).validator(object({ password: string().min(1) })).handler(createSsrRpc("dc06cb162796eb13be097f8c5488cec4ba1a2beecf8ee793c404775ff0bc17a5"));
var adminLogout = createServerFn({ method: "POST" }).validator(tokenSchema).handler(createSsrRpc("d1aac9ce809cd31884bb2cb8540d0cac862666e976a869ee2a58a8ea46be3c95"));
var lookupTeam = createServerFn({ method: "POST" }).validator(object({ nameOrCode: string() })).handler(createSsrRpc("bb697652da898157608269cb73c811c4774a9adb5d026776cf1d9692663bc2fe"));
var submitAllocation = createServerFn({ method: "POST" }).validator(object({
	nameOrCode: string(),
	allocations: array(allocationSchema)
})).handler(createSsrRpc("54de75a51fdcb9a565e6c138b7ab31a199a68c062396ef7acf3c816ace92d5c1"));
var addTeam = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	name: string(),
	pitch: string()
})).handler(createSsrRpc("24bdd167ba01d41ff77ed309ffc3ff21709940a9e606738feafee3fe475af969"));
var updateTeam = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	id: number().int(),
	name: string(),
	pitch: string()
})).handler(createSsrRpc("eead469d504d6d17847a4028c162ba686bdc39c90c427c718c6027c53eea5738"));
var removeTeam = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	id: number().int()
})).handler(createSsrRpc("141650e43b2f2e8baeeef993b6b59ffceffa14ecd07cc1b39ed9e6160fdf0d22"));
var updateSettings = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	initialAmount: number().int(),
	minInvestment: number().int(),
	deadline: string().nullable(),
	eventName: string(),
	venue: string(),
	eventWhen: string(),
	applyAmountToTeams: boolean()
})).handler(createSsrRpc("e7ac069c411f36c8168f1f63ea7ec6fbddb30fa8a6b9244de2a7cc0a5f848c9b"));
var setVotingOpen = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	open: boolean()
})).handler(createSsrRpc("f60c3447da71d3f3d3b7f9d44bff2188b37341c34cff7d82ee95efa58c74c81a"));
var clearVotes = createServerFn({ method: "POST" }).validator(tokenSchema).handler(createSsrRpc("bd5e0ec2e1ca9cc1f90802925969cea920e5035e6eb2747c7963bde0b6ce757e"));
var changePassword = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	current: string(),
	next: string()
})).handler(createSsrRpc("020ae1e96d438f49677569405eb396fae443ea6db9fe47d1485591eda6fa5c6a"));
//#endregion
export { submitAllocation as _, changePassword as a, formatInt as c, getPublicState as d, isoToLocal as f, setVotingOpen as g, removeTeam as h, adminLogout as i, formatRupee as l, parseRupeeInput as m, addTeam as n, clearVotes as o, lookupTeam as p, adminLogin as r, downloadCsv as s, Countdown as t, getAdminState as u, updateSettings as v, updateTeam as y };
