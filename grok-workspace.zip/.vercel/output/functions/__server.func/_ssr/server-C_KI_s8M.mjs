import { a as object, i as number, n as boolean, o as string, t as array } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-C_KI_s8M.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var tokenSchema = object({ token: string() });
var allocationSchema = object({
	toTeamId: number().int(),
	amount: number().int()
});
var getPublicState_createServerFn_handler = createServerRpc({
	id: "eaf634d561198a3cf7f34aabceb5fb2026530b179b76ef7435477fe5bbb31878",
	name: "getPublicState",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => getPublicState.__executeServer(opts));
var getPublicState = createServerFn({ method: "GET" }).handler(getPublicState_createServerFn_handler, async () => {
	const { loadPublicState } = await import("./queries.server-CBM6oKFJ.mjs");
	return loadPublicState();
});
var getAdminState_createServerFn_handler = createServerRpc({
	id: "731dd655d1a98dad530a0cf169789cb93b68d0415559453e6303794305df5063",
	name: "getAdminState",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => getAdminState.__executeServer(opts));
var getAdminState = createServerFn({ method: "POST" }).validator(tokenSchema).handler(getAdminState_createServerFn_handler, async ({ data }) => {
	const { loadAdminState } = await import("./queries.server-CBM6oKFJ.mjs");
	return loadAdminState(data.token);
});
var adminLogin_createServerFn_handler = createServerRpc({
	id: "dc06cb162796eb13be097f8c5488cec4ba1a2beecf8ee793c404775ff0bc17a5",
	name: "adminLogin",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => adminLogin.__executeServer(opts));
var adminLogin = createServerFn({ method: "POST" }).validator(object({ password: string().min(1) })).handler(adminLogin_createServerFn_handler, async ({ data }) => {
	const { loginAdmin } = await import("./queries.server-CBM6oKFJ.mjs");
	return loginAdmin(data.password);
});
var adminLogout_createServerFn_handler = createServerRpc({
	id: "d1aac9ce809cd31884bb2cb8540d0cac862666e976a869ee2a58a8ea46be3c95",
	name: "adminLogout",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => adminLogout.__executeServer(opts));
var adminLogout = createServerFn({ method: "POST" }).validator(tokenSchema).handler(adminLogout_createServerFn_handler, async ({ data }) => {
	const { logoutAdmin } = await import("./queries.server-CBM6oKFJ.mjs");
	return logoutAdmin(data.token);
});
var lookupTeam_createServerFn_handler = createServerRpc({
	id: "bb697652da898157608269cb73c811c4774a9adb5d026776cf1d9692663bc2fe",
	name: "lookupTeam",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => lookupTeam.__executeServer(opts));
var lookupTeam = createServerFn({ method: "POST" }).validator(object({ nameOrCode: string() })).handler(lookupTeam_createServerFn_handler, async ({ data }) => {
	const { lookupTeam: run } = await import("./queries.server-CBM6oKFJ.mjs");
	return run(data.nameOrCode);
});
var submitAllocation_createServerFn_handler = createServerRpc({
	id: "54de75a51fdcb9a565e6c138b7ab31a199a68c062396ef7acf3c816ace92d5c1",
	name: "submitAllocation",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => submitAllocation.__executeServer(opts));
var submitAllocation = createServerFn({ method: "POST" }).validator(object({
	nameOrCode: string(),
	allocations: array(allocationSchema)
})).handler(submitAllocation_createServerFn_handler, async ({ data }) => {
	const { submitAllocation: run } = await import("./queries.server-CBM6oKFJ.mjs");
	return run(data);
});
var addTeam_createServerFn_handler = createServerRpc({
	id: "24bdd167ba01d41ff77ed309ffc3ff21709940a9e606738feafee3fe475af969",
	name: "addTeam",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => addTeam.__executeServer(opts));
var addTeam = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	name: string(),
	pitch: string()
})).handler(addTeam_createServerFn_handler, async ({ data }) => {
	const { addTeam: run } = await import("./queries.server-CBM6oKFJ.mjs");
	return run(data.token, {
		name: data.name,
		pitch: data.pitch
	});
});
var updateTeam_createServerFn_handler = createServerRpc({
	id: "eead469d504d6d17847a4028c162ba686bdc39c90c427c718c6027c53eea5738",
	name: "updateTeam",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => updateTeam.__executeServer(opts));
var updateTeam = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	id: number().int(),
	name: string(),
	pitch: string()
})).handler(updateTeam_createServerFn_handler, async ({ data }) => {
	const { updateTeam: run } = await import("./queries.server-CBM6oKFJ.mjs");
	return run(data.token, {
		id: data.id,
		name: data.name,
		pitch: data.pitch
	});
});
var removeTeam_createServerFn_handler = createServerRpc({
	id: "141650e43b2f2e8baeeef993b6b59ffceffa14ecd07cc1b39ed9e6160fdf0d22",
	name: "removeTeam",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => removeTeam.__executeServer(opts));
var removeTeam = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	id: number().int()
})).handler(removeTeam_createServerFn_handler, async ({ data }) => {
	const { removeTeam: run } = await import("./queries.server-CBM6oKFJ.mjs");
	return run(data.token, data.id);
});
var updateSettings_createServerFn_handler = createServerRpc({
	id: "e7ac069c411f36c8168f1f63ea7ec6fbddb30fa8a6b9244de2a7cc0a5f848c9b",
	name: "updateSettings",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => updateSettings.__executeServer(opts));
var updateSettings = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	initialAmount: number().int(),
	minInvestment: number().int(),
	deadline: string().nullable(),
	eventName: string(),
	venue: string(),
	eventWhen: string(),
	applyAmountToTeams: boolean()
})).handler(updateSettings_createServerFn_handler, async ({ data }) => {
	const { updateSettings: run } = await import("./queries.server-CBM6oKFJ.mjs");
	const { token, ...rest } = data;
	return run(token, rest);
});
var setVotingOpen_createServerFn_handler = createServerRpc({
	id: "f60c3447da71d3f3d3b7f9d44bff2188b37341c34cff7d82ee95efa58c74c81a",
	name: "setVotingOpen",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => setVotingOpen.__executeServer(opts));
var setVotingOpen = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	open: boolean()
})).handler(setVotingOpen_createServerFn_handler, async ({ data }) => {
	const { setVotingOpen: run } = await import("./queries.server-CBM6oKFJ.mjs");
	return run(data.token, data.open);
});
var clearVotes_createServerFn_handler = createServerRpc({
	id: "bd5e0ec2e1ca9cc1f90802925969cea920e5035e6eb2747c7963bde0b6ce757e",
	name: "clearVotes",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => clearVotes.__executeServer(opts));
var clearVotes = createServerFn({ method: "POST" }).validator(tokenSchema).handler(clearVotes_createServerFn_handler, async ({ data }) => {
	const { clearVotes: run } = await import("./queries.server-CBM6oKFJ.mjs");
	return run(data.token);
});
var changePassword_createServerFn_handler = createServerRpc({
	id: "020ae1e96d438f49677569405eb396fae443ea6db9fe47d1485591eda6fa5c6a",
	name: "changePassword",
	filename: "src/lib/ideathon/server.ts"
}, (opts) => changePassword.__executeServer(opts));
var changePassword = createServerFn({ method: "POST" }).validator(object({
	token: string(),
	current: string(),
	next: string()
})).handler(changePassword_createServerFn_handler, async ({ data }) => {
	const { changePassword: run } = await import("./queries.server-CBM6oKFJ.mjs");
	return run(data.token, {
		current: data.current,
		next: data.next
	});
});
//#endregion
export { addTeam_createServerFn_handler, adminLogin_createServerFn_handler, adminLogout_createServerFn_handler, changePassword_createServerFn_handler, clearVotes_createServerFn_handler, getAdminState_createServerFn_handler, getPublicState_createServerFn_handler, lookupTeam_createServerFn_handler, removeTeam_createServerFn_handler, setVotingOpen_createServerFn_handler, submitAllocation_createServerFn_handler, updateSettings_createServerFn_handler, updateTeam_createServerFn_handler };
