import { x as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as cn, r as SiteHeader, t as LiveDot } from "./site-header-BxIe-v5s.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as formatInt, d as getPublicState, l as formatRupee, t as Countdown } from "./server-DwpbBz-w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/board-Cp6qQ63Z.js
var import_jsx_runtime = require_jsx_runtime();
function BoardPage() {
	const state = useQuery({
		queryKey: ["public-state"],
		queryFn: () => getPublicState(),
		refetchInterval: 2500
	}).data;
	const max = Math.max(1, ...state?.leaderboard.map((t) => t.received) ?? [1]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {
			live: state?.votingLive,
			dense: true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto flex w-full max-w-6xl flex-1 flex-col px-4 py-8 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
							children: "Projector board"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-4xl tracking-tight sm:text-5xl",
							children: state?.eventName ?? "IIC Ideathon"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: [
								state?.venue,
								" · ",
								state?.eventWhen
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveDot, { live: Boolean(state?.votingLive) }), state?.deadline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Countdown, { deadline: state.deadline }) : null]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardStat, {
							label: "Circulation",
							value: formatRupee(state?.totalInCirculation ?? 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardStat, {
							label: "Moved",
							value: formatRupee(state?.totalInvested ?? 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardStat, {
							label: "Ballots",
							value: `${formatInt(state?.submittedCount ?? 0)} / ${formatInt(state?.teamCount ?? 0)}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardStat, {
							label: "Participation",
							value: !state || state.teamCount === 0 ? "—" : `${Math.round(state.submittedCount / state.teamCount * 100)}%`
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 flex flex-col gap-3",
					children: (state?.leaderboard ?? []).map((team, index) => {
						const width = Math.max(6, Math.round(team.received / max * 100));
						const lead = index === 0 && team.received > 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: cn("rounded-xl bg-card px-4 py-4 shadow-border sm:px-6", lead && "shadow-border-hover"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-8 font-display text-xl tabular-nums text-muted-foreground",
											children: String(team.rank).padStart(2, "0")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "truncate font-display text-2xl tracking-tight sm:text-3xl",
											children: team.name
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 hidden text-sm text-muted-foreground sm:block sm:pl-11",
										children: [
											team.investorCount,
											" ",
											team.investorCount === 1 ? "investor" : "investors",
											team.pitch ? ` · ${team.pitch}` : ""
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "shrink-0 font-display text-2xl tabular-nums tracking-tight sm:text-3xl",
									children: formatRupee(team.received)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-2 overflow-hidden rounded-full bg-muted sm:ml-11",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-accent transition-[width] duration-[var(--motion-slow)] ease-[var(--ease-smooth-out)]",
									style: { width: `${width}%` }
								})
							})]
						}, team.id);
					})
				})
			]
		})]
	});
}
function BoardStat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card px-4 py-4 shadow-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-display text-2xl tabular-nums tracking-tight",
			children: value
		})]
	});
}
//#endregion
export { BoardPage as component };
