import { x as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as cn } from "./site-header-BxIe-v5s.mjs";
import { l as formatRupee } from "./server-DwpbBz-w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/leaderboard-list-Bpn1SBM7.js
var import_jsx_runtime = require_jsx_runtime();
function LeaderboardList({ teams, topInvestors, compact = false }) {
	const max = Math.max(1, ...teams.map((t) => t.received));
	if (teams.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Teams will appear here once the floor is set up."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "flex flex-col gap-3",
		children: teams.map((team) => {
			const width = Math.max(4, Math.round(team.received / max * 100));
			const investors = topInvestors?.[team.id] ?? [];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-lg bg-muted/60 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs tabular-nums text-muted-foreground",
									children: String(team.rank).padStart(2, "0")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "truncate font-display text-lg tracking-tight",
									children: team.name
								}),
								!compact && team.pitch ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 line-clamp-2 text-sm text-muted-foreground",
									children: team.pitch
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "shrink-0 font-display text-xl tabular-nums tracking-tight",
							children: formatRupee(team.received)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-1.5 overflow-hidden rounded-full bg-background",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("h-full rounded-full bg-accent transition-[width] duration-[var(--motion-slow)] ease-[var(--ease-smooth-out)]"),
							style: { width: `${width}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-muted-foreground",
						children: [
							team.investorCount,
							" ",
							team.investorCount === 1 ? "investor" : "investors",
							team.investorCount > 0 ? ` · avg ${formatRupee(team.averageInvestment)}` : ""
						]
					}),
					investors.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-1 text-xs text-muted-foreground",
						children: investors.map((inv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: inv.fromTeam
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-foreground",
								children: formatRupee(inv.amount)
							})]
						}, inv.fromTeam))
					}) : null
				]
			}, team.id);
		})
	});
}
//#endregion
export { LeaderboardList as t };
