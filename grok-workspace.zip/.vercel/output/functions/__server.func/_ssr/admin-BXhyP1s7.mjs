import { o as __toESM } from "../_runtime.mjs";
import { S as require_react, a as Overlay2, c as Title2, i as Description2, l as Trigger2, n as Cancel, o as Portal2, r as Content2, s as Root2, t as Action, x as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as cn, r as SiteHeader, t as LiveDot } from "./site-header-BxIe-v5s.mjs";
import { c as Download, i as Plus, n as Trash2 } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as buttonVariants, r as Button } from "./router-CDVpAFJK.mjs";
import { a as changePassword, f as isoToLocal, g as setVotingOpen, h as removeTeam, i as adminLogout, l as formatRupee, n as addTeam, o as clearVotes, r as adminLogin, s as downloadCsv, t as Countdown, u as getAdminState, v as updateSettings, y as updateTeam } from "./server-DwpbBz-w.mjs";
import { t as LeaderboardList } from "./leaderboard-list-Bpn1SBM7.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-BSIbSZtR.mjs";
import { n as Input, r as Label, t as ADMIN_TOKEN_KEY } from "./types-pUIe-9cF.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
import { i as Trigger, n as List, r as Root2$1, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-BXhyP1s7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-24 w-full rounded-md bg-muted px-3 py-2 text-sm text-foreground shadow-border transition-[box-shadow] duration-[var(--motion-quick)] placeholder:text-muted-foreground focus-visible:outline-none focus-visible:shadow-border-hover focus-visible:ring-2 focus-visible:ring-ring/60 disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var Tabs = Root2$1;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-11 items-center justify-start gap-1 rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-md px-3 text-sm font-medium whitespace-nowrap transition-[background-color,color] duration-[var(--motion-quick)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow-border", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-6 focus-visible:outline-none", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full shadow-border transition-colors duration-[var(--motion-quick)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-muted", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block size-5 rounded-full bg-background shadow-border transition-transform duration-[var(--motion-quick)] ease-[var(--ease-smooth-out)] data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0.5 data-[state=checked]:bg-primary-foreground") })
}));
Switch.displayName = Switch$1.displayName;
var AlertDialog = Root2;
var AlertDialogTrigger = Trigger2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	ref,
	className: cn("fixed inset-0 z-50 bg-background/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 grid w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-card p-6 text-card-foreground shadow-lift duration-[var(--motion-fast)] data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-2 text-left", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("font-display text-xl font-medium", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
function AdminPage() {
	const [token, setToken] = (0, import_react.useState)(null);
	const [booted, setBooted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setToken(window.localStorage.getItem(ADMIN_TOKEN_KEY));
		setBooted(true);
	}, []);
	function persist(next) {
		if (next) window.localStorage.setItem(ADMIN_TOKEN_KEY, next);
		else window.localStorage.removeItem(ADMIN_TOKEN_KEY);
		setToken(next);
	}
	if (!booted) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { className: "mx-auto flex w-full max-w-md flex-1 items-center px-4" })]
	});
	if (!token) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLogin, { onToken: persist });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminDesk, {
		token,
		onToken: persist
	});
}
function AdminLogin({ onToken }) {
	const [password, setPassword] = (0, import_react.useState)("");
	const loginMut = useMutation({
		mutationFn: () => adminLogin({ data: { password } }),
		onSuccess: (res) => {
			onToken(res.token);
			toast.success("Organizer desk unlocked.");
		},
		onError: (error) => toast.error(errorMessage(error))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-4 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
					children: "Organizers"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-4xl tracking-tight",
					children: "Sign in to the desk"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "Initial password is admin123. Change it in Setup before the hall fills."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-8 flex flex-col gap-4",
					onSubmit: (e) => {
						e.preventDefault();
						loginMut.mutate();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "password",
							children: "Password"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "password",
							type: "password",
							autoComplete: "current-password",
							value: password,
							onChange: (e) => setPassword(e.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: loginMut.isPending,
						children: loginMut.isPending ? "Checking" : "Enter desk"
					})]
				})
			]
		})]
	});
}
function AdminDesk({ token, onToken }) {
	const queryClient = useQueryClient();
	const adminQuery = useQuery({
		queryKey: ["admin-state", token],
		queryFn: () => getAdminState({ data: { token } }),
		refetchInterval: 2500,
		retry: false
	});
	(0, import_react.useEffect)(() => {
		if (!adminQuery.error) return;
		const message = errorMessage(adminQuery.error);
		if (/session expired|sign-in required/i.test(message)) {
			onToken(null);
			toast.error(message);
		}
	}, [adminQuery.error, onToken]);
	const logoutMut = useMutation({
		mutationFn: () => adminLogout({ data: { token } }),
		onSettled: () => onToken(null)
	});
	const state = adminQuery.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { live: state?.votingLive }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
						children: "Organizer desk"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl tracking-tight",
						children: state?.eventName ?? "Venture Floor"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveDot, { live: Boolean(state?.votingLive) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => logoutMut.mutate(),
							children: "Sign out"
						})]
					})]
				}),
				adminQuery.isError && !state ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm text-destructive",
					children: errorMessage(adminQuery.error)
				}) : null,
				state ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
					defaultValue: "live",
					className: "mt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
							className: "w-full overflow-x-auto sm:w-auto",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "live",
									children: "Live"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "setup",
									children: "Setup"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "votes",
									children: "Votes"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "live",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LivePanel, { state })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "setup",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetupPanel, {
								token,
								state,
								onChanged: () => queryClient.invalidateQueries({ queryKey: ["admin-state"] })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "votes",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VotesPanel, {
								token,
								state,
								onChanged: () => queryClient.invalidateQueries({ queryKey: ["admin-state"] })
							})
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 text-sm text-muted-foreground",
					children: "Loading desk…"
				})
			]
		})]
	});
}
function LivePanel({ state }) {
	const chart = [...state.leaderboard].slice().reverse().map((t) => ({
		name: t.name,
		received: t.received
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [state.deadline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Countdown, { deadline: state.deadline }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						state.submittedCount,
						" of ",
						state.teamCount,
						" envelopes in"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Circulation",
						value: formatRupee(state.totalInCirculation)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Moved",
						value: formatRupee(state.totalInvested)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Participation",
						value: state.teamCount === 0 ? "—" : `${Math.round(state.submittedCount / state.teamCount * 100)}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniStat, {
						label: "Lead",
						value: state.leaderboard[0]?.name ?? "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-[1.1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "rounded-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Capital received" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "h-72",
						children: chart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "No teams yet."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: chart,
								layout: "vertical",
								margin: {
									left: 8,
									right: 12
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										type: "number",
										hide: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										type: "category",
										dataKey: "name",
										width: 110,
										tick: {
											fill: "currentColor",
											fontSize: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										cursor: { fill: "color-mix(in oklab, var(--color-foreground) 6%, transparent)" },
										contentStyle: {
											background: "var(--color-card)",
											border: "1px solid var(--color-border)",
											borderRadius: 12
										},
										formatter: (value) => formatRupee(Number(value ?? 0))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "received",
										fill: "currentColor",
										radius: [
											0,
											6,
											6,
											0
										]
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-4 font-display text-2xl tracking-tight",
					children: "Leaderboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeaderboardList, {
					teams: state.leaderboard,
					topInvestors: state.topInvestors
				})] })]
			})
		]
	});
}
function MiniStat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 shadow-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 truncate font-display text-2xl tabular-nums tracking-tight",
			children: value
		})]
	});
}
function SetupPanel({ token, state, onChanged }) {
	const [name, setName] = (0, import_react.useState)("");
	const [pitch, setPitch] = (0, import_react.useState)("");
	const [eventName, setEventName] = (0, import_react.useState)(state.eventName);
	const [venue, setVenue] = (0, import_react.useState)(state.venue);
	const [eventWhen, setEventWhen] = (0, import_react.useState)(state.eventWhen);
	const [initialAmount, setInitialAmount] = (0, import_react.useState)(String(state.initialAmount));
	const [minInvestment, setMinInvestment] = (0, import_react.useState)(String(state.minInvestment));
	const [deadlineLocal, setDeadlineLocal] = (0, import_react.useState)(state.deadline ? toDatetimeLocal(state.deadline) : "");
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [nextPassword, setNextPassword] = (0, import_react.useState)("");
	const addMut = useMutation({
		mutationFn: () => addTeam({ data: {
			token,
			name,
			pitch
		} }),
		onSuccess: () => {
			setName("");
			setPitch("");
			toast.success("Team added.");
			onChanged();
		},
		onError: (error) => toast.error(errorMessage(error))
	});
	const settingsMut = useMutation({
		mutationFn: (applyAmountToTeams) => updateSettings({ data: {
			token,
			initialAmount: Number.parseInt(initialAmount, 10) || 0,
			minInvestment: Number.parseInt(minInvestment, 10) || 1,
			deadline: deadlineLocal ? new Date(deadlineLocal).toISOString() : null,
			eventName,
			venue,
			eventWhen,
			applyAmountToTeams
		} }),
		onSuccess: () => {
			toast.success("Settings saved.");
			onChanged();
		},
		onError: (error) => toast.error(errorMessage(error))
	});
	const votingMut = useMutation({
		mutationFn: (open) => setVotingOpen({ data: {
			token,
			open
		} }),
		onSuccess: (res) => {
			toast.success(res.votingOpen ? "Floor opened." : "Floor closed.");
			onChanged();
		},
		onError: (error) => toast.error(errorMessage(error))
	});
	const passwordMut = useMutation({
		mutationFn: () => changePassword({ data: {
			token,
			current: currentPassword,
			next: nextPassword
		} }),
		onSuccess: () => {
			setCurrentPassword("");
			setNextPassword("");
			toast.success("Password updated.");
		},
		onError: (error) => toast.error(errorMessage(error))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[1.1fr_0.9fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "rounded-2xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "flex flex-row items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Floor control" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Close the floor to edit the field. Opening it lets teams submit."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: state.votingOpen,
						onCheckedChange: (open) => votingMut.mutate(open),
						"aria-label": "Toggle voting"
					})]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "rounded-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Teams" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex flex-col gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex flex-col gap-3 rounded-lg bg-muted/60 p-4",
						onSubmit: (e) => {
							e.preventDefault();
							addMut.mutate();
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "new-team",
								children: "New team"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "new-team",
								value: name,
								placeholder: "Team name",
								onChange: (e) => setName(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: pitch,
								placeholder: "One-line pitch (optional)",
								onChange: (e) => setPitch(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "submit",
								disabled: addMut.isPending,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add team"]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-3",
						children: state.teams.map((team) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamRow, {
							token,
							team,
							canDelete: state.submittedCount === 0,
							onChanged
						}, team.id))
					})]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "rounded-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Event settings" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Event name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: eventName,
								onChange: (e) => setEventName(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Venue",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: venue,
								onChange: (e) => setVenue(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "When",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: eventWhen,
								onChange: (e) => setEventWhen(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Starting purse (₹)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "numeric",
								value: initialAmount,
								onChange: (e) => setInitialAmount(e.target.value.replace(/[^\d]/g, ""))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Minimum ticket (₹)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "numeric",
								value: minInvestment,
								onChange: (e) => setMinInvestment(e.target.value.replace(/[^\d]/g, ""))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Deadline (optional)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "datetime-local",
								value: deadlineLocal,
								onChange: (e) => setDeadlineLocal(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								className: "flex-1",
								onClick: () => settingsMut.mutate(false),
								disabled: settingsMut.isPending,
								children: "Save settings"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								className: "flex-1",
								onClick: () => settingsMut.mutate(true),
								disabled: settingsMut.isPending || state.submittedCount > 0,
								children: "Save + apply purse"
							})]
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "rounded-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Password" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "password",
							placeholder: "Current password",
							value: currentPassword,
							onChange: (e) => setCurrentPassword(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "password",
							placeholder: "New password",
							value: nextPassword,
							onChange: (e) => setNextPassword(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => passwordMut.mutate(),
							disabled: passwordMut.isPending,
							children: "Update password"
						})
					]
				})]
			})]
		})]
	});
}
function TeamRow({ token, team, canDelete, onChanged }) {
	const [name, setName] = (0, import_react.useState)(team.name);
	const [pitch, setPitch] = (0, import_react.useState)(team.pitch);
	const saveMut = useMutation({
		mutationFn: () => updateTeam({ data: {
			token,
			id: team.id,
			name,
			pitch
		} }),
		onSuccess: () => {
			toast.success("Team updated.");
			onChanged();
		},
		onError: (error) => toast.error(errorMessage(error))
	});
	const deleteMut = useMutation({
		mutationFn: () => removeTeam({ data: {
			token,
			id: team.id
		} }),
		onSuccess: () => {
			toast.success("Team removed.");
			onChanged();
		},
		onError: (error) => toast.error(errorMessage(error))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-lg bg-muted/60 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.18em] text-muted-foreground",
					children: team.code
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: team.submitted ? `Submitted · ${formatRupee(team.invested)}` : "Not submitted"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				className: "mt-3",
				value: name,
				onChange: (e) => setName(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				className: "mt-2",
				value: pitch,
				onChange: (e) => setPitch(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "sm",
					variant: "outline",
					onClick: () => saveMut.mutate(),
					disabled: saveMut.isPending,
					children: "Save"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					variant: "ghost",
					disabled: !canDelete || deleteMut.isPending,
					onClick: () => deleteMut.mutate(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Remove"]
				})]
			})
		]
	});
}
function VotesPanel({ token, state, onChanged }) {
	const clearMut = useMutation({
		mutationFn: () => clearVotes({ data: { token } }),
		onSuccess: () => {
			toast.success("Votes cleared. Teams remain.");
			onChanged();
		},
		onError: (error) => toast.error(errorMessage(error))
	});
	function exportCsv() {
		const rows = [
			[
				"From",
				"To",
				"Amount (INR)",
				"Submitted at"
			],
			...state.votes.map((v) => [
				v.fromTeam,
				v.toTeam,
				String(v.amount),
				v.timestamp
			]),
			[],
			[
				"Rank",
				"Team",
				"Received",
				"Investors",
				"Average"
			],
			...state.leaderboard.map((t) => [
				String(t.rank),
				t.name,
				String(t.received),
				String(t.investorCount),
				String(t.averageInvestment)
			])
		];
		const stamp = (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace(/[:T]/g, "-");
		downloadCsv(`venture-floor-${stamp}.csv`, rows);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:justify-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "outline",
					onClick: exportCsv,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Download CSV"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "destructive",
						children: "Clear votes"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Clear this round?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "Every envelope is deleted. Team names and codes stay. This cannot be undone." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Keep votes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					onClick: () => clearMut.mutate(),
					children: "Clear votes"
				})] })] })] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "rounded-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Who has voted" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2 sm:grid-cols-2",
					children: state.teams.map((team) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between rounded-md bg-muted/60 px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: team.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: team.submitted ? isoToLocal(team.submittedAt) : "Waiting"
						})]
					}, team.id))
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-2xl bg-card shadow-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[36rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-xs uppercase tracking-[0.14em] text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "From"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "To"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Amount"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "When"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: state.votes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-6 text-muted-foreground",
						colSpan: 4,
						children: "No envelopes yet."
					}) }) : state.votes.map((vote, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: vote.fromTeam
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: vote.toTeam
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums",
								children: formatRupee(vote.amount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-muted-foreground",
								children: isoToLocal(vote.timestamp)
							})
						]
					}, `${vote.fromTeamId}-${vote.toTeamId}-${index}`)) })]
				})
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium",
			children: label
		}), children]
	});
}
function toDatetimeLocal(iso) {
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return "";
	const pad = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	return "Something went wrong.";
}
//#endregion
export { AdminPage as component };
