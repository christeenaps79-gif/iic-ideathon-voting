import { x as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-header-BxIe-v5s.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function LiveDot({ live, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-2 text-xs font-medium tracking-wide uppercase",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("relative size-2 rounded-full", live ? "bg-success" : "bg-muted-foreground/50"),
			children: live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 animate-ping rounded-full bg-success/70" }) : null
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: live ? "text-success" : "text-muted-foreground",
			children: label ?? (live ? "Floor open" : "Floor closed")
		})]
	});
}
var links = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/vote",
		label: "Invest"
	},
	{
		to: "/board",
		label: "Board"
	},
	{
		to: "/admin",
		label: "Organizers"
	}
];
function SiteHeader({ live, dense = false }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: cn("sticky top-0 z-40 border-b border-border/80 bg-background/90 backdrop-blur-md", dense ? "px-4 py-3" : "px-4 py-4 sm:px-6"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "group min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg leading-none tracking-tight sm:text-xl",
					children: "Venture Floor"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 truncate text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
					children: "IIC Ideathon · CEA"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex items-center gap-1 sm:gap-2",
				children: [typeof live === "boolean" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mr-2 hidden sm:inline-flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveDot, { live })
				}) : null, links.map((link) => {
					const active = link.to === "/" ? pathname === "/" : pathname === link.to || pathname.startsWith(`${link.to}/`);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: link.to,
						className: cn("rounded-md px-2.5 py-2 text-sm transition-colors duration-[var(--motion-quick)] sm:px-3", active ? "bg-muted text-foreground" : "text-muted-foreground hover:text-foreground"),
						children: link.label
					}, link.to);
				})]
			})]
		})
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "mt-auto border-t border-border/80 px-4 py-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-2 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "College of Engineering Adoor · Institution Innovation Council" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Fake capital. Real conviction." })]
		})
	});
}
//#endregion
export { cn as i, SiteFooter as n, SiteHeader as r, LiveDot as t };
