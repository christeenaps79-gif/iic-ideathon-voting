import { o as __toESM } from "../_runtime.mjs";
import { S as require_react, x as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as cn, n as SiteFooter, r as SiteHeader, t as LiveDot } from "./site-header-BxIe-v5s.mjs";
import { l as Check, o as Lock } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route, r as Button } from "./router-CDVpAFJK.mjs";
import { _ as submitAllocation, d as getPublicState, l as formatRupee, m as parseRupeeInput, p as lookupTeam, t as Countdown } from "./server-DwpbBz-w.mjs";
import { n as CardContent, t as Card } from "./card-BSIbSZtR.mjs";
import { i as TEAM_SESSION_KEY, n as Input, r as Label } from "./types-pUIe-9cF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vote-BAMUD3NB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VotePage() {
	const { code } = Route.useSearch();
	const queryClient = useQueryClient();
	const [identity, setIdentity] = (0, import_react.useState)("");
	const [session, setSession] = (0, import_react.useState)(null);
	const [amounts, setAmounts] = (0, import_react.useState)({});
	const state = useQuery({
		queryKey: ["public-state"],
		queryFn: () => getPublicState(),
		refetchInterval: 4e3
	}).data;
	(0, import_react.useEffect)(() => {
		const fromUrl = code?.trim();
		const stored = window.localStorage.getItem(TEAM_SESSION_KEY);
		const start = fromUrl || stored || "";
		if (start) setIdentity(start);
		if (fromUrl) enter(fromUrl);
		else if (stored) enter(stored);
	}, [code]);
	const lookupMut = useMutation({
		mutationFn: (nameOrCode) => lookupTeam({ data: { nameOrCode } }),
		onSuccess: (result) => {
			setSession(result);
			window.localStorage.setItem(TEAM_SESSION_KEY, result.team.code);
			const next = {};
			for (const row of result.allocations) next[row.toTeamId] = String(row.amount);
			setAmounts(next);
		},
		onError: (error) => toast.error(errorMessage(error))
	});
	const submitMut = useMutation({
		mutationFn: () => {
			if (!session) throw new Error("Identify your team first.");
			const allocations = Object.entries(amounts).map(([id, raw]) => ({
				toTeamId: Number(id),
				amount: parseRupeeInput(raw)
			})).filter((row) => row.amount > 0);
			return submitAllocation({ data: {
				nameOrCode: session.team.code,
				allocations
			} });
		},
		onSuccess: (result) => {
			setSession(result);
			queryClient.invalidateQueries({ queryKey: ["public-state"] });
			toast.success("Allocation locked.");
		},
		onError: (error) => toast.error(errorMessage(error))
	});
	function enter(value) {
		const nameOrCode = (value ?? identity).trim();
		if (!nameOrCode) {
			toast.error("Enter your team name or code.");
			return;
		}
		lookupMut.mutate(nameOrCode);
	}
	const others = (0, import_react.useMemo)(() => (state?.leaderboard ?? []).filter((team) => team.id !== session?.team.id), [state?.leaderboard, session?.team.id]);
	const spent = (0, import_react.useMemo)(() => {
		return Object.values(amounts).reduce((sum, raw) => sum + parseRupeeInput(raw), 0);
	}, [amounts]);
	const purse = session?.team.initialBalance ?? state?.initialAmount ?? 0;
	const remaining = purse - spent;
	const over = remaining < 0;
	const allocatedPct = purse === 0 ? 0 : Math.min(100, Math.round(spent / purse * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { live: state?.votingLive }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 py-10 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
						children: "Investment desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl tracking-tight",
						children: "Allocate capital"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-muted-foreground",
						children: "Identify your team, then split the purse across everyone else. You get one locked envelope."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveDot, { live: Boolean(state?.votingLive) }), state?.deadline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Countdown, { deadline: state.deadline }) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "mt-8 rounded-2xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "p-5 sm:p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "team-id",
									children: "Team name or code"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-col gap-2 sm:flex-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "team-id",
										value: identity,
										autoComplete: "off",
										placeholder: "Aether or K7M2",
										onChange: (e) => setIdentity(e.target.value),
										onKeyDown: (e) => {
											if (e.key === "Enter") {
												e.preventDefault();
												enter();
											}
										}
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										onClick: () => enter(),
										disabled: lookupMut.isPending,
										className: "sm:w-36",
										children: lookupMut.isPending ? "Checking" : "Enter"
									})]
								}),
								session ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-sm text-muted-foreground",
									children: [
										"Signed in as",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground",
											children: session.team.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-2 tracking-[0.18em]",
											children: session.team.code
										})
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-muted-foreground",
									children: "Ask an organizer for your four-letter code if the name does not match."
								})
							]
						})
					}),
					session ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sticky top-[4.25rem] z-30 mt-6 rounded-xl bg-background/95 p-4 shadow-border backdrop-blur-md",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.16em] text-muted-foreground",
								children: "Remaining"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: cn("font-display text-3xl tabular-nums tracking-tight", over && "text-destructive"),
								children: formatRupee(remaining)
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm tabular-nums text-muted-foreground",
								children: [
									formatRupee(spent),
									" of ",
									formatRupee(purse)
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-1.5 overflow-hidden rounded-full bg-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("h-full rounded-full transition-[width,background-color] duration-[var(--motion-fast)]", over ? "bg-destructive" : "bg-accent"),
								style: { width: `${over ? 100 : allocatedPct}%` }
							})
						})]
					}) : null,
					session?.submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "mt-6 rounded-2xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "p-5 sm:p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-success",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium",
										children: "Envelope locked"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm text-muted-foreground",
									children: [
										session.team.name,
										" has submitted. Remaining",
										" ",
										formatRupee(session.remaining),
										". You can look, but you cannot edit."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-5 divide-y divide-border",
									children: session.allocations.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-3 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.toTeamName }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums",
											children: formatRupee(row.amount)
										})]
									}, row.toTeamId))
								})
							]
						})
					}) : null,
					session && !session.submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-6 flex flex-col gap-3 pb-28",
						onSubmit: (e) => {
							e.preventDefault();
							if (over) {
								toast.error("You are over the purse.");
								return;
							}
							submitMut.mutate();
						},
						children: [
							!state?.votingLive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 rounded-lg bg-muted px-3 py-3 text-sm text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }), "The floor is closed. You can draft, but you cannot submit."]
							}) : null,
							others.map((team) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block rounded-xl bg-card p-4 shadow-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-lg tracking-tight",
											children: team.name
										}), team.pitch ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm text-muted-foreground",
											children: team.pitch
										}) : null]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "numeric",
										className: "h-11 w-28 text-right tabular-nums",
										placeholder: "0",
										value: amounts[team.id] ?? "",
										onChange: (e) => setAmounts((prev) => ({
											...prev,
											[team.id]: e.target.value.replace(/[^\d]/g, "")
										})),
										"aria-label": `Amount for ${team.name}`
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex flex-wrap gap-2",
									children: [[
										100,
										250,
										500
									].map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-9 rounded-full px-3 text-xs text-muted-foreground shadow-border transition-colors hover:bg-muted hover:text-foreground",
										onClick: () => setAmounts((prev) => ({
											...prev,
											[team.id]: String(chip)
										})),
										children: formatRupee(chip)
									}, chip)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-9 rounded-full px-3 text-xs text-muted-foreground shadow-border transition-colors hover:bg-muted hover:text-foreground",
										onClick: () => {
											const usedElsewhere = Object.entries(amounts).reduce((sum, [id, raw]) => Number(id) === team.id ? sum : sum + parseRupeeInput(raw), 0);
											const rest = Math.max(0, purse - usedElsewhere);
											setAmounts((prev) => ({
												...prev,
												[team.id]: String(rest)
											}));
										},
										children: "Rest of purse"
									})]
								})]
							}, team.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 px-4 py-3 backdrop-blur-md",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mx-auto flex max-w-3xl gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										className: "flex-1",
										onClick: () => setAmounts({}),
										children: "Clear"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "submit",
										className: "flex-[2]",
										disabled: submitMut.isPending || over || spent <= 0 || !state?.votingLive,
										children: submitMut.isPending ? "Locking" : "Lock allocation"
									})]
								})
							})
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	return "Something went wrong.";
}
//#endregion
export { VotePage as component };
