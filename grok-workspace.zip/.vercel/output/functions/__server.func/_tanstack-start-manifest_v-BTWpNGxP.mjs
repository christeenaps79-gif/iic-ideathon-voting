//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BTWpNGxP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/board",
			"/vote"
		],
		preloads: ["/assets/index-CNv0bNXa.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CNv0bNXa.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BxTxwJ4h.js",
			"/assets/server-CII-evUl.js",
			"/assets/leaderboard-list-DAvqg8ju.js",
			"/assets/card-eX-O_2d7.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-B7i0KHaI.js",
			"/assets/server-CII-evUl.js",
			"/assets/types-HDm1CYAM.js",
			"/assets/leaderboard-list-DAvqg8ju.js",
			"/assets/card-eX-O_2d7.js"
		]
	},
	"/board": {
		filePath: "/workspace/src/routes/board.tsx",
		children: void 0,
		preloads: ["/assets/board-BbOBkaoh.js", "/assets/server-CII-evUl.js"]
	},
	"/vote": {
		filePath: "/workspace/src/routes/vote.tsx",
		children: void 0,
		preloads: [
			"/assets/vote-BJE7v_JM.js",
			"/assets/server-CII-evUl.js",
			"/assets/types-HDm1CYAM.js",
			"/assets/card-eX-O_2d7.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
