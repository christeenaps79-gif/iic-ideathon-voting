-- IIC Ideathon · Venture Floor
-- Shared event data (no user accounts). Rows are unowned and world-readable
-- through public server functions; mutations that change the event are gated
-- by an organizer session token.

create table if not exists event_settings (
  id integer primary key check (id = 1),
  admin_password_hash text not null,
  initial_amount integer not null default 1000,
  min_investment integer not null default 1,
  voting_open boolean not null default false,
  deadline timestamptz,
  event_name text not null default 'IIC Ideathon',
  venue text not null default 'SDPK Hall, College of Engineering Adoor',
  event_when text not null default '15 September 2026 · 9:00 AM – 12:30 PM',
  updated_at timestamptz not null default now()
);

create table if not exists teams (
  id serial primary key,
  name text not null,
  code text not null,
  pitch text not null default '',
  initial_balance integer not null,
  created_at timestamptz not null default now()
);

create unique index if not exists teams_name_lower_idx on teams (lower(name));
create unique index if not exists teams_code_idx on teams (code);

create table if not exists submissions (
  from_team_id integer primary key references teams(id) on delete cascade,
  allocations jsonb not null default '[]'::jsonb,
  remaining integer not null default 0,
  submitted_at timestamptz not null default now()
);

create table if not exists admin_sessions (
  token text primary key,
  created_at timestamptz not null default now()
);
