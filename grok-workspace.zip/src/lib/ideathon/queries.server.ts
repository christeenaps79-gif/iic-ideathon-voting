import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { getSql, type Sql } from "@/lib/db";
import type {
  AdminState,
  Allocation,
  LookupResult,
  PublicState,
  PublicTeam,
  TeamAdmin,
  TopInvestor,
  VoteRecord,
} from "./types";

const DEFAULT_PASSWORD = "admin123";

const DEMO_TEAMS: Array<{ name: string; pitch: string }> = [
  {
    name: "Aether",
    pitch: "Low-cost air-quality mesh for campus hostels.",
  },
  {
    name: "Circuit Breakers",
    pitch: "Smart energy trip system that saves lab equipment.",
  },
  {
    name: "GreenShift",
    pitch: "Canteen food-waste to biogas, sized for CEA.",
  },
  {
    name: "NexLab",
    pitch: "Offline AR lab manuals for first-year workshops.",
  },
  {
    name: "PixelForge",
    pitch: "Exam proctoring that works without a cloud lock-in.",
  },
  {
    name: "HydroLogic",
    pitch: "Acoustic leak detection for campus water lines.",
  },
];

type SettingsRow = {
  admin_password_hash: string;
  initial_amount: number;
  min_investment: number;
  voting_open: boolean;
  deadline: string | Date | null;
  event_name: string;
  venue: string;
  event_when: string;
};

type TeamRow = {
  id: number;
  name: string;
  code: string;
  pitch: string;
  initial_balance: number;
};

type SubmissionRow = {
  from_team_id: number;
  allocations: unknown;
  remaining: number;
  submitted_at: string | Date;
};

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 32).toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const next = scryptSync(password, salt, 32);
  const prev = Buffer.from(hash, "hex");
  if (next.length !== prev.length) return false;
  return timingSafeEqual(next, prev);
}

function newCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  const bytes = randomBytes(4);
  for (let i = 0; i < 4; i += 1) {
    out += alphabet[bytes[i]! % alphabet.length];
  }
  return out;
}

function toIso(value: string | Date | null | undefined): string | null {
  if (!value) return null;
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}

function asAllocations(raw: unknown): Allocation[] {
  if (typeof raw === "string") {
    try {
      raw = JSON.parse(raw) as unknown;
    } catch {
      return [];
    }
  }
  if (!Array.isArray(raw)) return [];
  return raw
    .map((item) => {
      if (!item || typeof item !== "object") return null;
      const rec = item as { toTeamId?: unknown; amount?: unknown };
      const toTeamId = Number(rec.toTeamId);
      const amount = Number(rec.amount);
      if (!Number.isInteger(toTeamId) || !Number.isInteger(amount)) return null;
      return { toTeamId, amount };
    })
    .filter((row): row is Allocation => row !== null && row.amount > 0);
}

function isUniqueViolation(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  const rec = error as { code?: string; message?: string };
  if (rec.code === "23505") return true;
  return typeof rec.message === "string" && /unique/i.test(rec.message);
}

async function uniqueCode(sql: Sql, taken: Set<string>): Promise<string> {
  for (let i = 0; i < 24; i += 1) {
    const code = newCode();
    if (taken.has(code)) continue;
    const rows = await sql<{ code: string }>`select code from teams where code = ${code}`;
    if (rows.length === 0) {
      taken.add(code);
      return code;
    }
  }
  throw new Error("Could not allocate a team code. Try again.");
}

let readyPromise: Promise<void> | null = null;

async function ensureReady(sql: Sql): Promise<void> {
  const existing = await sql<{ id: number }>`select id from event_settings where id = 1`;
  if (existing.length === 0) {
    await sql.query(
      `insert into event_settings (id, admin_password_hash, initial_amount, voting_open)
       values (1, $1, 1000, true)
       on conflict (id) do nothing`,
      [hashPassword(DEFAULT_PASSWORD)],
    );
  }

  const teamCount = await sql<{ n: number }>`select count(*)::int as n from teams`;
  if ((teamCount[0]?.n ?? 0) === 0) {
    const settings = await loadSettings(sql);
    const taken = new Set<string>();
    for (const team of DEMO_TEAMS) {
      const code = await uniqueCode(sql, taken);
      try {
        await sql.query(
          `insert into teams (name, code, pitch, initial_balance) values ($1, $2, $3, $4)`,
          [team.name, code, team.pitch, settings.initial_amount],
        );
      } catch (error) {
        if (!isUniqueViolation(error)) throw error;
      }
    }
  }
}

export async function withDb<T>(fn: (sql: Sql) => Promise<T>): Promise<T> {
  const sql = await getSql();
  readyPromise ??= ensureReady(sql).catch((error) => {
    readyPromise = null;
    throw error;
  });
  await readyPromise;
  return fn(sql);
}

async function loadSettings(sql: Sql): Promise<SettingsRow> {
  const rows = await sql<SettingsRow>`
    select admin_password_hash, initial_amount, min_investment, voting_open,
           deadline, event_name, venue, event_when
    from event_settings where id = 1
  `;
  const row = rows[0];
  if (!row) throw new Error("Event settings are missing.");
  return row;
}

function votingIsLive(settings: SettingsRow, now = new Date()): boolean {
  if (!settings.voting_open) return false;
  const deadline = toIso(settings.deadline);
  if (!deadline) return true;
  return new Date(deadline).getTime() > now.getTime();
}

async function loadTeams(sql: Sql): Promise<TeamRow[]> {
  return sql<TeamRow>`
    select id, name, code, pitch, initial_balance
    from teams
    order by lower(name) asc, id asc
  `;
}

async function loadSubmissions(sql: Sql): Promise<SubmissionRow[]> {
  return sql<SubmissionRow>`
    select from_team_id, allocations, remaining, submitted_at
    from submissions
  `;
}

function buildLeaderboard(
  teams: TeamRow[],
  submissions: SubmissionRow[],
): {
  leaderboard: PublicTeam[];
  votes: VoteRecord[];
  topInvestors: Record<number, TopInvestor[]>;
  totalInvested: number;
} {
  const nameById = new Map(teams.map((t) => [t.id, t.name]));
  const received = new Map<number, { total: number; investors: TopInvestor[] }>();
  for (const team of teams) {
    received.set(team.id, { total: 0, investors: [] });
  }

  const votes: VoteRecord[] = [];
  let totalInvested = 0;

  for (const sub of submissions) {
    const fromName = nameById.get(sub.from_team_id) ?? "Unknown";
    const stamp = toIso(sub.submitted_at) ?? new Date().toISOString();
    for (const alloc of asAllocations(sub.allocations)) {
      totalInvested += alloc.amount;
      const bucket = received.get(alloc.toTeamId);
      if (bucket) {
        bucket.total += alloc.amount;
        bucket.investors.push({ fromTeam: fromName, amount: alloc.amount });
      }
      votes.push({
        fromTeamId: sub.from_team_id,
        fromTeam: fromName,
        toTeamId: alloc.toTeamId,
        toTeam: nameById.get(alloc.toTeamId) ?? "Unknown",
        amount: alloc.amount,
        timestamp: stamp,
      });
    }
  }

  const ranked = [...teams]
    .map((team) => {
      const bucket = received.get(team.id) ?? { total: 0, investors: [] };
      const investorCount = bucket.investors.length;
      return {
        id: team.id,
        name: team.name,
        pitch: team.pitch,
        received: bucket.total,
        investorCount,
        averageInvestment:
          investorCount === 0 ? 0 : Math.round(bucket.total / investorCount),
        rank: 0,
      } satisfies PublicTeam;
    })
    .sort((a, b) => {
      if (b.received !== a.received) return b.received - a.received;
      return a.name.localeCompare(b.name);
    });

  let lastReceived = Number.POSITIVE_INFINITY;
  let lastRank = 0;
  ranked.forEach((team, index) => {
    if (team.received < lastReceived) {
      lastRank = index + 1;
      lastReceived = team.received;
    }
    team.rank = lastRank;
  });

  const topInvestors: Record<number, TopInvestor[]> = {};
  for (const team of teams) {
    const bucket = received.get(team.id);
    topInvestors[team.id] = (bucket?.investors ?? [])
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 5);
  }

  votes.sort((a, b) => b.timestamp.localeCompare(a.timestamp));

  return { leaderboard: ranked, votes, topInvestors, totalInvested };
}

function toPublicState(
  settings: SettingsRow,
  teams: TeamRow[],
  submissions: SubmissionRow[],
): PublicState {
  const now = new Date();
  const { leaderboard, totalInvested } = buildLeaderboard(teams, submissions);
  const totalInCirculation = teams.reduce((sum, t) => sum + t.initial_balance, 0);
  return {
    eventName: settings.event_name,
    venue: settings.venue,
    eventWhen: settings.event_when,
    votingOpen: settings.voting_open,
    votingLive: votingIsLive(settings, now),
    deadline: toIso(settings.deadline),
    initialAmount: settings.initial_amount,
    minInvestment: settings.min_investment,
    teamCount: teams.length,
    submittedCount: submissions.length,
    totalInCirculation,
    totalInvested,
    leaderboard,
    now: now.toISOString(),
  };
}

export async function loadPublicState(): Promise<PublicState> {
  return withDb(async (sql) => {
    const [settings, teams, submissions] = await Promise.all([
      loadSettings(sql),
      loadTeams(sql),
      loadSubmissions(sql),
    ]);
    return toPublicState(settings, teams, submissions);
  });
}

export async function loadAdminState(token: string): Promise<AdminState> {
  return withDb(async (sql) => {
    await assertAdmin(sql, token);
    const [settings, teams, submissions] = await Promise.all([
      loadSettings(sql),
      loadTeams(sql),
      loadSubmissions(sql),
    ]);
    const publicState = toPublicState(settings, teams, submissions);
    const { votes, topInvestors } = buildLeaderboard(teams, submissions);
    const subByTeam = new Map(submissions.map((s) => [s.from_team_id, s]));
    const adminTeams: TeamAdmin[] = teams.map((team) => {
      const sub = subByTeam.get(team.id);
      const invested = sub
        ? asAllocations(sub.allocations).reduce((sum, a) => sum + a.amount, 0)
        : 0;
      return {
        id: team.id,
        name: team.name,
        code: team.code,
        pitch: team.pitch,
        initialBalance: team.initial_balance,
        submitted: Boolean(sub),
        submittedAt: sub ? toIso(sub.submitted_at) : null,
        remaining: sub ? sub.remaining : team.initial_balance,
        invested,
      };
    });
    return { ...publicState, teams: adminTeams, votes, topInvestors };
  });
}

async function assertAdmin(sql: Sql, token: string): Promise<void> {
  if (!token) throw new Error("Organizer sign-in required.");
  const rows = await sql<{ token: string }>`
    select token from admin_sessions
    where token = ${token}
      and created_at > now() - interval '12 hours'
  `;
  if (rows.length === 0) {
    throw new Error("Organizer session expired. Sign in again.");
  }
}

export async function loginAdmin(password: string): Promise<{ token: string }> {
  return withDb(async (sql) => {
    const settings = await loadSettings(sql);
    if (!verifyPassword(password, settings.admin_password_hash)) {
      throw new Error("That password does not match.");
    }
    await sql`delete from admin_sessions where created_at < now() - interval '12 hours'`;
    const token = randomBytes(32).toString("hex");
    await sql`insert into admin_sessions (token) values (${token})`;
    return { token };
  });
}

export async function logoutAdmin(token: string): Promise<{ ok: true }> {
  return withDb(async (sql) => {
    if (token) {
      await sql`delete from admin_sessions where token = ${token}`;
    }
    return { ok: true as const };
  });
}

export async function lookupTeam(nameOrCode: string): Promise<LookupResult> {
  return withDb(async (sql) => {
    const needle = nameOrCode.trim();
    if (!needle) throw new Error("Enter your team name or code.");
    const teams = await sql<TeamRow>`
      select id, name, code, pitch, initial_balance
      from teams
      where lower(name) = lower(${needle}) or upper(code) = upper(${needle})
      limit 1
    `;
    const team = teams[0];
    if (!team) throw new Error("No team matches that name or code.");
    const subs = await sql<SubmissionRow>`
      select from_team_id, allocations, remaining, submitted_at
      from submissions
      where from_team_id = ${team.id}
    `;
    const sub = subs[0];
    const nameById = new Map(
      (await loadTeams(sql)).map((t) => [t.id, t.name] as const),
    );
    const allocations = sub
      ? asAllocations(sub.allocations).map((a) => ({
          toTeamId: a.toTeamId,
          toTeamName: nameById.get(a.toTeamId) ?? "Unknown",
          amount: a.amount,
        }))
      : [];
    return {
      team: {
        id: team.id,
        name: team.name,
        code: team.code,
        initialBalance: team.initial_balance,
      },
      submitted: Boolean(sub),
      submittedAt: sub ? toIso(sub.submitted_at) : null,
      remaining: sub ? sub.remaining : team.initial_balance,
      allocations,
    };
  });
}

export async function submitAllocation(input: {
  nameOrCode: string;
  allocations: Allocation[];
}): Promise<LookupResult> {
  return withDb(async (sql) => {
    const settings = await loadSettings(sql);
    if (!votingIsLive(settings)) {
      throw new Error("Voting is closed.");
    }
    const lookup = await lookupTeam(input.nameOrCode);
    if (lookup.submitted) {
      throw new Error("This team has already submitted. Allocations are locked.");
    }

    const teams = await loadTeams(sql);
    const teamIds = new Set(teams.map((t) => t.id));
    const cleaned: Allocation[] = [];
    let spent = 0;

    for (const row of input.allocations) {
      const amount = Math.round(Number(row.amount) || 0);
      const toTeamId = Number(row.toTeamId);
      if (amount <= 0) continue;
      if (!Number.isInteger(amount)) {
        throw new Error("Amounts must be whole rupees.");
      }
      if (amount < settings.min_investment) {
        throw new Error(`Minimum investment is ₹${settings.min_investment}.`);
      }
      if (toTeamId === lookup.team.id) {
        throw new Error("You cannot invest in your own idea.");
      }
      if (!teamIds.has(toTeamId)) {
        throw new Error("One of the selected teams no longer exists.");
      }
      if (cleaned.some((a) => a.toTeamId === toTeamId)) {
        throw new Error("Each team can only appear once in your allocation.");
      }
      spent += amount;
      cleaned.push({ toTeamId, amount });
    }

    if (cleaned.length === 0) {
      throw new Error("Allocate at least ₹1 to another team.");
    }
    if (spent > lookup.team.initialBalance) {
      throw new Error("You cannot invest more than your purse.");
    }

    const remaining = lookup.team.initialBalance - spent;

    try {
      await sql.query(
        `insert into submissions (from_team_id, allocations, remaining)
         values ($1, $2::jsonb, $3)`,
        [lookup.team.id, JSON.stringify(cleaned), remaining],
      );
    } catch (error) {
      if (isUniqueViolation(error)) {
        throw new Error("This team has already submitted. Allocations are locked.");
      }
      throw error;
    }

    return lookupTeam(input.nameOrCode);
  });
}

export async function addTeam(
  token: string,
  input: { name: string; pitch: string },
): Promise<TeamAdmin> {
  return withDb(async (sql) => {
    await assertAdmin(sql, token);
    const settings = await loadSettings(sql);
    const submissions = await loadSubmissions(sql);
    if (settings.voting_open && submissions.length > 0) {
      throw new Error("Close voting before adding teams mid-round.");
    }
    const name = input.name.trim();
    if (name.length < 2) throw new Error("Team name needs at least 2 characters.");
    if (name.length > 48) throw new Error("Keep team names under 48 characters.");
    const pitch = input.pitch.trim().slice(0, 180);
    const code = await uniqueCode(sql, new Set());
    try {
      const rows = await sql<{ id: number }>`
        insert into teams (name, code, pitch, initial_balance)
        values (${name}, ${code}, ${pitch}, ${settings.initial_amount})
        returning id
      `;
      const id = rows[0]?.id;
      if (!id) throw new Error("Could not add team.");
      return {
        id,
        name,
        code,
        pitch,
        initialBalance: settings.initial_amount,
        submitted: false,
        submittedAt: null,
        remaining: settings.initial_amount,
        invested: 0,
      };
    } catch (error) {
      if (isUniqueViolation(error)) {
        throw new Error("A team with that name already exists.");
      }
      throw error;
    }
  });
}

export async function updateTeam(
  token: string,
  input: { id: number; name: string; pitch: string },
): Promise<{ ok: true }> {
  return withDb(async (sql) => {
    await assertAdmin(sql, token);
    const name = input.name.trim();
    if (name.length < 2) throw new Error("Team name needs at least 2 characters.");
    if (name.length > 48) throw new Error("Keep team names under 48 characters.");
    const pitch = input.pitch.trim().slice(0, 180);
    try {
      const rows = await sql<{ id: number }>`
        update teams set name = ${name}, pitch = ${pitch}
        where id = ${input.id}
        returning id
      `;
      if (!rows[0]) throw new Error("Team not found.");
      return { ok: true as const };
    } catch (error) {
      if (isUniqueViolation(error)) {
        throw new Error("A team with that name already exists.");
      }
      throw error;
    }
  });
}

export async function removeTeam(token: string, id: number): Promise<{ ok: true }> {
  return withDb(async (sql) => {
    await assertAdmin(sql, token);
    const submissions = await loadSubmissions(sql);
    if (submissions.length > 0) {
      throw new Error("Clear votes before removing a team.");
    }
    await sql`delete from teams where id = ${id}`;
    return { ok: true as const };
  });
}

export async function updateSettings(
  token: string,
  input: {
    initialAmount: number;
    minInvestment: number;
    deadline: string | null;
    eventName: string;
    venue: string;
    eventWhen: string;
    applyAmountToTeams: boolean;
  },
): Promise<{ ok: true }> {
  return withDb(async (sql) => {
    await assertAdmin(sql, token);
    const initialAmount = Math.round(input.initialAmount);
    const minInvestment = Math.round(input.minInvestment);
    if (initialAmount < 10 || initialAmount > 1_000_000) {
      throw new Error("Starting purse must be between ₹10 and ₹10,00,000.");
    }
    if (minInvestment < 1 || minInvestment > initialAmount) {
      throw new Error("Minimum investment must be at least ₹1 and within the purse.");
    }
    const deadline = input.deadline?.trim() ? input.deadline : null;
    if (deadline && Number.isNaN(new Date(deadline).getTime())) {
      throw new Error("Deadline is not a valid time.");
    }
    await sql.query(
      `update event_settings
       set initial_amount = $1,
           min_investment = $2,
           deadline = $3,
           event_name = $4,
           venue = $5,
           event_when = $6,
           updated_at = now()
       where id = 1`,
      [
        initialAmount,
        minInvestment,
        deadline,
        input.eventName.trim() || "IIC Ideathon",
        input.venue.trim() || "SDPK Hall, College of Engineering Adoor",
        input.eventWhen.trim() || "15 September 2026 · 9:00 AM – 12:30 PM",
      ],
    );
    if (input.applyAmountToTeams) {
      const submissions = await loadSubmissions(sql);
      if (submissions.length > 0) {
        throw new Error("Clear votes before changing every team's purse.");
      }
      await sql`update teams set initial_balance = ${initialAmount}`;
    }
    return { ok: true as const };
  });
}

export async function setVotingOpen(
  token: string,
  open: boolean,
): Promise<{ ok: true; votingOpen: boolean }> {
  return withDb(async (sql) => {
    await assertAdmin(sql, token);
    const teams = await loadTeams(sql);
    if (open && teams.length < 2) {
      throw new Error("Add at least two teams before opening the floor.");
    }
    await sql`update event_settings set voting_open = ${open}, updated_at = now() where id = 1`;
    return { ok: true as const, votingOpen: open };
  });
}

export async function clearVotes(token: string): Promise<{ ok: true }> {
  return withDb(async (sql) => {
    await assertAdmin(sql, token);
    await sql`delete from submissions`;
    return { ok: true as const };
  });
}

export async function changePassword(
  token: string,
  input: { current: string; next: string },
): Promise<{ ok: true }> {
  return withDb(async (sql) => {
    await assertAdmin(sql, token);
    const settings = await loadSettings(sql);
    if (!verifyPassword(input.current, settings.admin_password_hash)) {
      throw new Error("Current password is incorrect.");
    }
    if (input.next.trim().length < 6) {
      throw new Error("New password must be at least 6 characters.");
    }
    const hash = hashPassword(input.next.trim());
    await sql`update event_settings set admin_password_hash = ${hash}, updated_at = now() where id = 1`;
    await sql`delete from admin_sessions where token <> ${token}`;
    return { ok: true as const };
  });
}
