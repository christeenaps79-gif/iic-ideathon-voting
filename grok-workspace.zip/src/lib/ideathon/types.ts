export type Allocation = {
  toTeamId: number;
  amount: number;
};

export type PublicTeam = {
  id: number;
  name: string;
  pitch: string;
  received: number;
  investorCount: number;
  averageInvestment: number;
  rank: number;
};

export type PublicState = {
  eventName: string;
  venue: string;
  eventWhen: string;
  votingOpen: boolean;
  votingLive: boolean;
  deadline: string | null;
  initialAmount: number;
  minInvestment: number;
  teamCount: number;
  submittedCount: number;
  totalInCirculation: number;
  totalInvested: number;
  leaderboard: PublicTeam[];
  now: string;
};

export type VoteRecord = {
  fromTeamId: number;
  fromTeam: string;
  toTeamId: number;
  toTeam: string;
  amount: number;
  timestamp: string;
};

export type TeamAdmin = {
  id: number;
  name: string;
  code: string;
  pitch: string;
  initialBalance: number;
  submitted: boolean;
  submittedAt: string | null;
  remaining: number;
  invested: number;
};

export type TopInvestor = {
  fromTeam: string;
  amount: number;
};

export type AdminState = PublicState & {
  teams: TeamAdmin[];
  votes: VoteRecord[];
  topInvestors: Record<number, TopInvestor[]>;
};

export type LookupResult = {
  team: {
    id: number;
    name: string;
    code: string;
    initialBalance: number;
  };
  submitted: boolean;
  submittedAt: string | null;
  remaining: number;
  allocations: Array<{ toTeamId: number; toTeamName: string; amount: number }>;
};

export const ADMIN_TOKEN_KEY = "venture-floor-admin";
export const TEAM_SESSION_KEY = "venture-floor-team";
