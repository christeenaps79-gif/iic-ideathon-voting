import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const tokenSchema = z.object({ token: z.string() });
const allocationSchema = z.object({
  toTeamId: z.number().int(),
  amount: z.number().int(),
});

export const getPublicState = createServerFn({ method: "GET" }).handler(
  async () => {
    const { loadPublicState } = await import("./queries.server");
    return loadPublicState();
  },
);

export const getAdminState = createServerFn({ method: "POST" })
  .validator(tokenSchema)
  .handler(async ({ data }) => {
    const { loadAdminState } = await import("./queries.server");
    return loadAdminState(data.token);
  });

export const adminLogin = createServerFn({ method: "POST" })
  .validator(z.object({ password: z.string().min(1) }))
  .handler(async ({ data }) => {
    const { loginAdmin } = await import("./queries.server");
    return loginAdmin(data.password);
  });

export const adminLogout = createServerFn({ method: "POST" })
  .validator(tokenSchema)
  .handler(async ({ data }) => {
    const { logoutAdmin } = await import("./queries.server");
    return logoutAdmin(data.token);
  });

export const lookupTeam = createServerFn({ method: "POST" })
  .validator(z.object({ nameOrCode: z.string() }))
  .handler(async ({ data }) => {
    const { lookupTeam: run } = await import("./queries.server");
    return run(data.nameOrCode);
  });

export const submitAllocation = createServerFn({ method: "POST" })
  .validator(
    z.object({
      nameOrCode: z.string(),
      allocations: z.array(allocationSchema),
    }),
  )
  .handler(async ({ data }) => {
    const { submitAllocation: run } = await import("./queries.server");
    return run(data);
  });

export const addTeam = createServerFn({ method: "POST" })
  .validator(
    z.object({
      token: z.string(),
      name: z.string(),
      pitch: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const { addTeam: run } = await import("./queries.server");
    return run(data.token, { name: data.name, pitch: data.pitch });
  });

export const updateTeam = createServerFn({ method: "POST" })
  .validator(
    z.object({
      token: z.string(),
      id: z.number().int(),
      name: z.string(),
      pitch: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const { updateTeam: run } = await import("./queries.server");
    return run(data.token, {
      id: data.id,
      name: data.name,
      pitch: data.pitch,
    });
  });

export const removeTeam = createServerFn({ method: "POST" })
  .validator(z.object({ token: z.string(), id: z.number().int() }))
  .handler(async ({ data }) => {
    const { removeTeam: run } = await import("./queries.server");
    return run(data.token, data.id);
  });

export const updateSettings = createServerFn({ method: "POST" })
  .validator(
    z.object({
      token: z.string(),
      initialAmount: z.number().int(),
      minInvestment: z.number().int(),
      deadline: z.string().nullable(),
      eventName: z.string(),
      venue: z.string(),
      eventWhen: z.string(),
      applyAmountToTeams: z.boolean(),
    }),
  )
  .handler(async ({ data }) => {
    const { updateSettings: run } = await import("./queries.server");
    const { token, ...rest } = data;
    return run(token, rest);
  });

export const setVotingOpen = createServerFn({ method: "POST" })
  .validator(z.object({ token: z.string(), open: z.boolean() }))
  .handler(async ({ data }) => {
    const { setVotingOpen: run } = await import("./queries.server");
    return run(data.token, data.open);
  });

export const clearVotes = createServerFn({ method: "POST" })
  .validator(tokenSchema)
  .handler(async ({ data }) => {
    const { clearVotes: run } = await import("./queries.server");
    return run(data.token);
  });

export const changePassword = createServerFn({ method: "POST" })
  .validator(
    z.object({
      token: z.string(),
      current: z.string(),
      next: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    const { changePassword: run } = await import("./queries.server");
    return run(data.token, { current: data.current, next: data.next });
  });
