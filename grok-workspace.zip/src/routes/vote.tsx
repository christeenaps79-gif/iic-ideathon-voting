import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Check, Lock } from "lucide-react";
import { SiteFooter, SiteHeader } from "@/components/site-header";
import { Countdown } from "@/components/countdown";
import { LiveDot } from "@/components/live-dot";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { lookupTeam, getPublicState, submitAllocation } from "@/lib/ideathon/server";
import { formatRupee, parseRupeeInput } from "@/lib/ideathon/format";
import { TEAM_SESSION_KEY, type LookupResult } from "@/lib/ideathon/types";
import { cn } from "@/lib/utils";

type VoteSearch = { code?: string };

export const Route = createFileRoute("/vote")({
  validateSearch: (search: Record<string, unknown>): VoteSearch => ({
    code: typeof search.code === "string" ? search.code : undefined,
  }),
  component: VotePage,
});

function VotePage() {
  const { code } = Route.useSearch();
  const queryClient = useQueryClient();
  const [identity, setIdentity] = useState("");
  const [session, setSession] = useState<LookupResult | null>(null);
  const [amounts, setAmounts] = useState<Record<number, string>>({});

  const publicQuery = useQuery({
    queryKey: ["public-state"],
    queryFn: () => getPublicState(),
    refetchInterval: 4000,
  });
  const state = publicQuery.data;

  useEffect(() => {
    const fromUrl = code?.trim();
    const stored = window.localStorage.getItem(TEAM_SESSION_KEY);
    const start = fromUrl || stored || "";
    if (start) setIdentity(start);
    if (fromUrl) {
      void enter(fromUrl);
    } else if (stored) {
      void enter(stored);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [code]);

  const lookupMut = useMutation({
    mutationFn: (nameOrCode: string) => lookupTeam({ data: { nameOrCode } }),
    onSuccess: (result) => {
      setSession(result);
      window.localStorage.setItem(TEAM_SESSION_KEY, result.team.code);
      const next: Record<number, string> = {};
      for (const row of result.allocations) next[row.toTeamId] = String(row.amount);
      setAmounts(next);
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  const submitMut = useMutation({
    mutationFn: () => {
      if (!session) throw new Error("Identify your team first.");
      const allocations = Object.entries(amounts)
        .map(([id, raw]) => ({
          toTeamId: Number(id),
          amount: parseRupeeInput(raw),
        }))
        .filter((row) => row.amount > 0);
      return submitAllocation({
        data: { nameOrCode: session.team.code, allocations },
      });
    },
    onSuccess: (result) => {
      setSession(result);
      void queryClient.invalidateQueries({ queryKey: ["public-state"] });
      toast.success("Allocation locked.");
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  function enter(value?: string) {
    const nameOrCode = (value ?? identity).trim();
    if (!nameOrCode) {
      toast.error("Enter your team name or code.");
      return;
    }
    lookupMut.mutate(nameOrCode);
  }

  const others = useMemo(
    () =>
      (state?.leaderboard ?? []).filter(
        (team) => team.id !== session?.team.id,
      ),
    [state?.leaderboard, session?.team.id],
  );

  const spent = useMemo(() => {
    return Object.values(amounts).reduce((sum, raw) => sum + parseRupeeInput(raw), 0);
  }, [amounts]);

  const purse = session?.team.initialBalance ?? state?.initialAmount ?? 0;
  const remaining = purse - spent;
  const over = remaining < 0;
  const allocatedPct = purse === 0 ? 0 : Math.min(100, Math.round((spent / purse) * 100));

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader live={state?.votingLive} />
      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 py-10 sm:px-6">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Investment desk
        </p>
        <h1 className="mt-3 font-display text-4xl tracking-tight">Allocate capital</h1>
        <p className="mt-3 max-w-xl text-muted-foreground">
          Identify your team, then split the purse across everyone else. You get
          one locked envelope.
        </p>

        <div className="mt-6 flex flex-wrap items-center gap-4">
          <LiveDot live={Boolean(state?.votingLive)} />
          {state?.deadline ? <Countdown deadline={state.deadline} /> : null}
        </div>

        <Card className="mt-8 rounded-2xl">
          <CardContent className="p-5 sm:p-6">
            <Label htmlFor="team-id">Team name or code</Label>
            <div className="mt-2 flex flex-col gap-2 sm:flex-row">
              <Input
                id="team-id"
                value={identity}
                autoComplete="off"
                placeholder="Aether or K7M2"
                onChange={(e) => setIdentity(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    enter();
                  }
                }}
              />
              <Button
                type="button"
                onClick={() => enter()}
                disabled={lookupMut.isPending}
                className="sm:w-36"
              >
                {lookupMut.isPending ? "Checking" : "Enter"}
              </Button>
            </div>
            {session ? (
              <p className="mt-3 text-sm text-muted-foreground">
                Signed in as{" "}
                <span className="text-foreground">{session.team.name}</span>
                <span className="ml-2 tracking-[0.18em]">{session.team.code}</span>
              </p>
            ) : (
              <p className="mt-3 text-sm text-muted-foreground">
                Ask an organizer for your four-letter code if the name does not
                match.
              </p>
            )}
          </CardContent>
        </Card>

        {session ? (
          <div className="sticky top-[4.25rem] z-30 mt-6 rounded-xl bg-background/95 p-4 shadow-border backdrop-blur-md">
            <div className="flex items-end justify-between gap-3">
              <div>
                <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground">
                  Remaining
                </p>
                <p
                  className={cn(
                    "font-display text-3xl tabular-nums tracking-tight",
                    over && "text-destructive",
                  )}
                >
                  {formatRupee(remaining)}
                </p>
              </div>
              <p className="text-sm tabular-nums text-muted-foreground">
                {formatRupee(spent)} of {formatRupee(purse)}
              </p>
            </div>
            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-muted">
              <div
                className={cn(
                  "h-full rounded-full transition-[width,background-color] duration-[var(--motion-fast)]",
                  over ? "bg-destructive" : "bg-accent",
                )}
                style={{ width: `${over ? 100 : allocatedPct}%` }}
              />
            </div>
          </div>
        ) : null}

        {session?.submitted ? (
          <Card className="mt-6 rounded-2xl">
            <CardContent className="p-5 sm:p-6">
              <div className="flex items-center gap-2 text-success">
                <Check className="size-4" />
                <p className="text-sm font-medium">Envelope locked</p>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                {session.team.name} has submitted. Remaining{" "}
                {formatRupee(session.remaining)}. You can look, but you cannot
                edit.
              </p>
              <ul className="mt-5 divide-y divide-border">
                {session.allocations.map((row) => (
                  <li
                    key={row.toTeamId}
                    className="flex items-center justify-between gap-3 py-3"
                  >
                    <span>{row.toTeamName}</span>
                    <span className="tabular-nums">{formatRupee(row.amount)}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ) : null}

        {session && !session.submitted ? (
          <form
            className="mt-6 flex flex-col gap-3 pb-28"
            onSubmit={(e) => {
              e.preventDefault();
              if (over) {
                toast.error("You are over the purse.");
                return;
              }
              submitMut.mutate();
            }}
          >
            {!state?.votingLive ? (
              <p className="flex items-center gap-2 rounded-lg bg-muted px-3 py-3 text-sm text-muted-foreground">
                <Lock className="size-4" />
                The floor is closed. You can draft, but you cannot submit.
              </p>
            ) : null}
            {others.map((team) => (
              <label
                key={team.id}
                className="block rounded-xl bg-card p-4 shadow-border"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-display text-lg tracking-tight">{team.name}</p>
                    {team.pitch ? (
                      <p className="mt-1 text-sm text-muted-foreground">{team.pitch}</p>
                    ) : null}
                  </div>
                  <Input
                    inputMode="numeric"
                    className="h-11 w-28 text-right tabular-nums"
                    placeholder="0"
                    value={amounts[team.id] ?? ""}
                    onChange={(e) =>
                      setAmounts((prev) => ({
                        ...prev,
                        [team.id]: e.target.value.replace(/[^\d]/g, ""),
                      }))
                    }
                    aria-label={`Amount for ${team.name}`}
                  />
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {[100, 250, 500].map((chip) => (
                    <button
                      key={chip}
                      type="button"
                      className="h-9 rounded-full px-3 text-xs text-muted-foreground shadow-border transition-colors hover:bg-muted hover:text-foreground"
                      onClick={() =>
                        setAmounts((prev) => ({
                          ...prev,
                          [team.id]: String(chip),
                        }))
                      }
                    >
                      {formatRupee(chip)}
                    </button>
                  ))}
                  <button
                    type="button"
                    className="h-9 rounded-full px-3 text-xs text-muted-foreground shadow-border transition-colors hover:bg-muted hover:text-foreground"
                    onClick={() => {
                      const usedElsewhere = Object.entries(amounts).reduce(
                        (sum, [id, raw]) =>
                          Number(id) === team.id ? sum : sum + parseRupeeInput(raw),
                        0,
                      );
                      const rest = Math.max(0, purse - usedElsewhere);
                      setAmounts((prev) => ({ ...prev, [team.id]: String(rest) }));
                    }}
                  >
                    Rest of purse
                  </button>
                </div>
              </label>
            ))}

            <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 px-4 py-3 backdrop-blur-md">
              <div className="mx-auto flex max-w-3xl gap-3">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => setAmounts({})}
                >
                  Clear
                </Button>
                <Button
                  type="submit"
                  className="flex-[2]"
                  disabled={
                    submitMut.isPending ||
                    over ||
                    spent <= 0 ||
                    !state?.votingLive
                  }
                >
                  {submitMut.isPending ? "Locking" : "Lock allocation"}
                </Button>
              </div>
            </div>
          </form>
        ) : null}
      </main>
      <SiteFooter />
    </div>
  );
}

function errorMessage(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  return "Something went wrong.";
}
