import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { SiteHeader } from "@/components/site-header";
import { LiveDot } from "@/components/live-dot";
import { Countdown } from "@/components/countdown";
import { getPublicState } from "@/lib/ideathon/server";
import { formatInt, formatRupee } from "@/lib/ideathon/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/board")({ component: BoardPage });

function BoardPage() {
  const stateQuery = useQuery({
    queryKey: ["public-state"],
    queryFn: () => getPublicState(),
    refetchInterval: 2500,
  });
  const state = stateQuery.data;
  const max = Math.max(1, ...(state?.leaderboard.map((t) => t.received) ?? [1]));

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader live={state?.votingLive} dense />
      <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col px-4 py-8 sm:px-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Projector board
            </p>
            <h1 className="mt-2 font-display text-4xl tracking-tight sm:text-5xl">
              {state?.eventName ?? "IIC Ideathon"}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {state?.venue} · {state?.eventWhen}
            </p>
          </div>
          <div className="flex flex-wrap items-end gap-6">
            <LiveDot live={Boolean(state?.votingLive)} />
            {state?.deadline ? <Countdown deadline={state.deadline} /> : null}
          </div>
        </div>

        <dl className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <BoardStat label="Circulation" value={formatRupee(state?.totalInCirculation ?? 0)} />
          <BoardStat label="Moved" value={formatRupee(state?.totalInvested ?? 0)} />
          <BoardStat
            label="Ballots"
            value={`${formatInt(state?.submittedCount ?? 0)} / ${formatInt(state?.teamCount ?? 0)}`}
          />
          <BoardStat
            label="Participation"
            value={
              !state || state.teamCount === 0
                ? "—"
                : `${Math.round((state.submittedCount / state.teamCount) * 100)}%`
            }
          />
        </dl>

        <ol className="mt-8 flex flex-col gap-3">
          {(state?.leaderboard ?? []).map((team, index) => {
            const width = Math.max(6, Math.round((team.received / max) * 100));
            const lead = index === 0 && team.received > 0;
            return (
              <li
                key={team.id}
                className={cn(
                  "rounded-xl bg-card px-4 py-4 shadow-border sm:px-6",
                  lead && "shadow-border-hover",
                )}
              >
                <div className="flex items-baseline justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-baseline gap-3">
                      <span className="w-8 font-display text-xl tabular-nums text-muted-foreground">
                        {String(team.rank).padStart(2, "0")}
                      </span>
                      <h2 className="truncate font-display text-2xl tracking-tight sm:text-3xl">
                        {team.name}
                      </h2>
                    </div>
                    <p className="mt-1 hidden text-sm text-muted-foreground sm:block sm:pl-11">
                      {team.investorCount}{" "}
                      {team.investorCount === 1 ? "investor" : "investors"}
                      {team.pitch ? ` · ${team.pitch}` : ""}
                    </p>
                  </div>
                  <p className="shrink-0 font-display text-2xl tabular-nums tracking-tight sm:text-3xl">
                    {formatRupee(team.received)}
                  </p>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted sm:ml-11">
                  <div
                    className="h-full rounded-full bg-accent transition-[width] duration-[var(--motion-slow)] ease-[var(--ease-smooth-out)]"
                    style={{ width: `${width}%` }}
                  />
                </div>
              </li>
            );
          })}
        </ol>
      </main>
    </div>
  );
}

function BoardStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-card px-4 py-4 shadow-border">
      <dt className="text-xs uppercase tracking-[0.16em] text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-display text-2xl tabular-nums tracking-tight">{value}</dd>
    </div>
  );
}
