import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type ReactNode } from "react";
import { toast } from "sonner";
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Download, Plus, Trash2 } from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { LeaderboardList } from "@/components/leaderboard-list";
import { LiveDot } from "@/components/live-dot";
import { Countdown } from "@/components/countdown";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  adminLogin,
  adminLogout,
  getAdminState,
  addTeam,
  updateTeam,
  removeTeam,
  updateSettings,
  setVotingOpen,
  clearVotes,
  changePassword,
} from "@/lib/ideathon/server";
import { downloadCsv, formatRupee, isoToLocal } from "@/lib/ideathon/format";
import { ADMIN_TOKEN_KEY, type AdminState, type TeamAdmin } from "@/lib/ideathon/types";

export const Route = createFileRoute("/admin")({ component: AdminPage });

function AdminPage() {
  const [token, setToken] = useState<string | null>(null);
  const [booted, setBooted] = useState(false);

  useEffect(() => {
    setToken(window.localStorage.getItem(ADMIN_TOKEN_KEY));
    setBooted(true);
  }, []);

  function persist(next: string | null) {
    if (next) window.localStorage.setItem(ADMIN_TOKEN_KEY, next);
    else window.localStorage.removeItem(ADMIN_TOKEN_KEY);
    setToken(next);
  }

  if (!booted) {
    return (
      <div className="flex min-h-dvh flex-col">
        <SiteHeader />
        <main className="mx-auto flex w-full max-w-md flex-1 items-center px-4" />
      </div>
    );
  }

  if (!token) {
    return <AdminLogin onToken={persist} />;
  }

  return <AdminDesk token={token} onToken={persist} />;
}

function AdminLogin({ onToken }: { onToken: (token: string) => void }) {
  const [password, setPassword] = useState("");
  const loginMut = useMutation({
    mutationFn: () => adminLogin({ data: { password } }),
    onSuccess: (res) => {
      onToken(res.token);
      toast.success("Organizer desk unlocked.");
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-4 py-16">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Organizers
        </p>
        <h1 className="mt-3 font-display text-4xl tracking-tight">Sign in to the desk</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          Initial password is admin123. Change it in Setup before the hall fills.
        </p>
        <form
          className="mt-8 flex flex-col gap-4"
          onSubmit={(e) => {
            e.preventDefault();
            loginMut.mutate();
          }}
        >
          <div className="flex flex-col gap-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <Button type="submit" disabled={loginMut.isPending}>
            {loginMut.isPending ? "Checking" : "Enter desk"}
          </Button>
        </form>
      </main>
    </div>
  );
}

function AdminDesk({
  token,
  onToken,
}: {
  token: string;
  onToken: (token: string | null) => void;
}) {
  const queryClient = useQueryClient();
  const adminQuery = useQuery({
    queryKey: ["admin-state", token],
    queryFn: () => getAdminState({ data: { token } }),
    refetchInterval: 2500,
    retry: false,
  });

  useEffect(() => {
    if (!adminQuery.error) return;
    const message = errorMessage(adminQuery.error);
    if (/session expired|sign-in required/i.test(message)) {
      onToken(null);
      toast.error(message);
    }
  }, [adminQuery.error, onToken]);

  const logoutMut = useMutation({
    mutationFn: () => adminLogout({ data: { token } }),
    onSettled: () => onToken(null),
  });

  const state = adminQuery.data;

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader live={state?.votingLive} />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Organizer desk
            </p>
            <h1 className="mt-2 font-display text-4xl tracking-tight">
              {state?.eventName ?? "Venture Floor"}
            </h1>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <LiveDot live={Boolean(state?.votingLive)} />
            <Button variant="outline" onClick={() => logoutMut.mutate()}>
              Sign out
            </Button>
          </div>
        </div>

        {adminQuery.isError && !state ? (
          <p className="mt-8 text-sm text-destructive">{errorMessage(adminQuery.error)}</p>
        ) : null}

        {state ? (
          <Tabs defaultValue="live" className="mt-8">
            <TabsList className="w-full overflow-x-auto sm:w-auto">
              <TabsTrigger value="live">Live</TabsTrigger>
              <TabsTrigger value="setup">Setup</TabsTrigger>
              <TabsTrigger value="votes">Votes</TabsTrigger>
            </TabsList>
            <TabsContent value="live">
              <LivePanel state={state} />
            </TabsContent>
            <TabsContent value="setup">
              <SetupPanel
                token={token}
                state={state}
                onChanged={() =>
                  queryClient.invalidateQueries({ queryKey: ["admin-state"] })
                }
              />
            </TabsContent>
            <TabsContent value="votes">
              <VotesPanel
                token={token}
                state={state}
                onChanged={() =>
                  queryClient.invalidateQueries({ queryKey: ["admin-state"] })
                }
              />
            </TabsContent>
          </Tabs>
        ) : (
          <p className="mt-10 text-sm text-muted-foreground">Loading desk…</p>
        )}
      </main>
    </div>
  );
}

function LivePanel({ state }: { state: AdminState }) {
  const chart = [...state.leaderboard]
    .slice()
    .reverse()
    .map((t) => ({ name: t.name, received: t.received }));

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        {state.deadline ? <Countdown deadline={state.deadline} /> : null}
        <p className="text-sm text-muted-foreground">
          {state.submittedCount} of {state.teamCount} envelopes in
        </p>
      </div>
      <dl className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <MiniStat label="Circulation" value={formatRupee(state.totalInCirculation)} />
        <MiniStat label="Moved" value={formatRupee(state.totalInvested)} />
        <MiniStat
          label="Participation"
          value={
            state.teamCount === 0
              ? "—"
              : `${Math.round((state.submittedCount / state.teamCount) * 100)}%`
          }
        />
        <MiniStat
          label="Lead"
          value={state.leaderboard[0]?.name ?? "—"}
        />
      </dl>
      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle>Capital received</CardTitle>
          </CardHeader>
          <CardContent className="h-72">
            {chart.length === 0 ? (
              <p className="text-sm text-muted-foreground">No teams yet.</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chart} layout="vertical" margin={{ left: 8, right: 12 }}>
                  <XAxis type="number" hide />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={110}
                    tick={{ fill: "currentColor", fontSize: 12 }}
                  />
                  <Tooltip
                    cursor={{ fill: "color-mix(in oklab, var(--color-foreground) 6%, transparent)" }}
                    contentStyle={{
                      background: "var(--color-card)",
                      border: "1px solid var(--color-border)",
                      borderRadius: 12,
                    }}
                    formatter={(value) => formatRupee(Number(value ?? 0))}
                  />
                  <Bar dataKey="received" fill="currentColor" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
        <div>
          <h2 className="mb-4 font-display text-2xl tracking-tight">Leaderboard</h2>
          <LeaderboardList teams={state.leaderboard} topInvestors={state.topInvestors} />
        </div>
      </div>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-card p-4 shadow-border">
      <dt className="text-xs uppercase tracking-[0.16em] text-muted-foreground">{label}</dt>
      <dd className="mt-1 truncate font-display text-2xl tabular-nums tracking-tight">
        {value}
      </dd>
    </div>
  );
}

function SetupPanel({
  token,
  state,
  onChanged,
}: {
  token: string;
  state: AdminState;
  onChanged: () => void;
}) {
  const [name, setName] = useState("");
  const [pitch, setPitch] = useState("");
  const [eventName, setEventName] = useState(state.eventName);
  const [venue, setVenue] = useState(state.venue);
  const [eventWhen, setEventWhen] = useState(state.eventWhen);
  const [initialAmount, setInitialAmount] = useState(String(state.initialAmount));
  const [minInvestment, setMinInvestment] = useState(String(state.minInvestment));
  const [deadlineLocal, setDeadlineLocal] = useState(
    state.deadline ? toDatetimeLocal(state.deadline) : "",
  );
  const [currentPassword, setCurrentPassword] = useState("");
  const [nextPassword, setNextPassword] = useState("");

  const addMut = useMutation({
    mutationFn: () => addTeam({ data: { token, name, pitch } }),
    onSuccess: () => {
      setName("");
      setPitch("");
      toast.success("Team added.");
      onChanged();
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  const settingsMut = useMutation({
    mutationFn: (applyAmountToTeams: boolean) =>
      updateSettings({
        data: {
          token,
          initialAmount: Number.parseInt(initialAmount, 10) || 0,
          minInvestment: Number.parseInt(minInvestment, 10) || 1,
          deadline: deadlineLocal ? new Date(deadlineLocal).toISOString() : null,
          eventName,
          venue,
          eventWhen,
          applyAmountToTeams,
        },
      }),
    onSuccess: () => {
      toast.success("Settings saved.");
      onChanged();
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  const votingMut = useMutation({
    mutationFn: (open: boolean) => setVotingOpen({ data: { token, open } }),
    onSuccess: (res) => {
      toast.success(res.votingOpen ? "Floor opened." : "Floor closed.");
      onChanged();
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  const passwordMut = useMutation({
    mutationFn: () =>
      changePassword({
        data: { token, current: currentPassword, next: nextPassword },
      }),
    onSuccess: () => {
      setCurrentPassword("");
      setNextPassword("");
      toast.success("Password updated.");
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  return (
    <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
      <div className="flex flex-col gap-6">
        <Card className="rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between gap-3">
            <div>
              <CardTitle>Floor control</CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">
                Close the floor to edit the field. Opening it lets teams submit.
              </p>
            </div>
            <Switch
              checked={state.votingOpen}
              onCheckedChange={(open) => votingMut.mutate(open)}
              aria-label="Toggle voting"
            />
          </CardHeader>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle>Teams</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <form
              className="flex flex-col gap-3 rounded-lg bg-muted/60 p-4"
              onSubmit={(e) => {
                e.preventDefault();
                addMut.mutate();
              }}
            >
              <Label htmlFor="new-team">New team</Label>
              <Input
                id="new-team"
                value={name}
                placeholder="Team name"
                onChange={(e) => setName(e.target.value)}
              />
              <Textarea
                value={pitch}
                placeholder="One-line pitch (optional)"
                onChange={(e) => setPitch(e.target.value)}
              />
              <Button type="submit" disabled={addMut.isPending}>
                <Plus />
                Add team
              </Button>
            </form>
            <ul className="flex flex-col gap-3">
              {state.teams.map((team) => (
                <TeamRow
                  key={team.id}
                  token={token}
                  team={team}
                  canDelete={state.submittedCount === 0}
                  onChanged={onChanged}
                />
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col gap-6">
        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle>Event settings</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <Field label="Event name">
              <Input value={eventName} onChange={(e) => setEventName(e.target.value)} />
            </Field>
            <Field label="Venue">
              <Input value={venue} onChange={(e) => setVenue(e.target.value)} />
            </Field>
            <Field label="When">
              <Input value={eventWhen} onChange={(e) => setEventWhen(e.target.value)} />
            </Field>
            <Field label="Starting purse (₹)">
              <Input
                inputMode="numeric"
                value={initialAmount}
                onChange={(e) => setInitialAmount(e.target.value.replace(/[^\d]/g, ""))}
              />
            </Field>
            <Field label="Minimum ticket (₹)">
              <Input
                inputMode="numeric"
                value={minInvestment}
                onChange={(e) => setMinInvestment(e.target.value.replace(/[^\d]/g, ""))}
              />
            </Field>
            <Field label="Deadline (optional)">
              <Input
                type="datetime-local"
                value={deadlineLocal}
                onChange={(e) => setDeadlineLocal(e.target.value)}
              />
            </Field>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button
                type="button"
                className="flex-1"
                onClick={() => settingsMut.mutate(false)}
                disabled={settingsMut.isPending}
              >
                Save settings
              </Button>
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => settingsMut.mutate(true)}
                disabled={settingsMut.isPending || state.submittedCount > 0}
              >
                Save + apply purse
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader>
            <CardTitle>Password</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            <Input
              type="password"
              placeholder="Current password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
            />
            <Input
              type="password"
              placeholder="New password"
              value={nextPassword}
              onChange={(e) => setNextPassword(e.target.value)}
            />
            <Button
              type="button"
              variant="outline"
              onClick={() => passwordMut.mutate()}
              disabled={passwordMut.isPending}
            >
              Update password
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function TeamRow({
  token,
  team,
  canDelete,
  onChanged,
}: {
  token: string;
  team: TeamAdmin;
  canDelete: boolean;
  onChanged: () => void;
}) {
  const [name, setName] = useState(team.name);
  const [pitch, setPitch] = useState(team.pitch);

  const saveMut = useMutation({
    mutationFn: () => updateTeam({ data: { token, id: team.id, name, pitch } }),
    onSuccess: () => {
      toast.success("Team updated.");
      onChanged();
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  const deleteMut = useMutation({
    mutationFn: () => removeTeam({ data: { token, id: team.id } }),
    onSuccess: () => {
      toast.success("Team removed.");
      onChanged();
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  return (
    <li className="rounded-lg bg-muted/60 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs tracking-[0.18em] text-muted-foreground">{team.code}</p>
        <p className="text-xs text-muted-foreground">
          {team.submitted ? `Submitted · ${formatRupee(team.invested)}` : "Not submitted"}
        </p>
      </div>
      <Input
        className="mt-3"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <Textarea
        className="mt-2"
        value={pitch}
        onChange={(e) => setPitch(e.target.value)}
      />
      <div className="mt-3 flex gap-2">
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={() => saveMut.mutate()}
          disabled={saveMut.isPending}
        >
          Save
        </Button>
        <Button
          type="button"
          size="sm"
          variant="ghost"
          disabled={!canDelete || deleteMut.isPending}
          onClick={() => deleteMut.mutate()}
        >
          <Trash2 />
          Remove
        </Button>
      </div>
    </li>
  );
}

function VotesPanel({
  token,
  state,
  onChanged,
}: {
  token: string;
  state: AdminState;
  onChanged: () => void;
}) {
  const clearMut = useMutation({
    mutationFn: () => clearVotes({ data: { token } }),
    onSuccess: () => {
      toast.success("Votes cleared. Teams remain.");
      onChanged();
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  function exportCsv() {
    const rows: string[][] = [
      ["From", "To", "Amount (INR)", "Submitted at"],
      ...state.votes.map((v) => [
        v.fromTeam,
        v.toTeam,
        String(v.amount),
        v.timestamp,
      ]),
      [],
      ["Rank", "Team", "Received", "Investors", "Average"],
      ...state.leaderboard.map((t) => [
        String(t.rank),
        t.name,
        String(t.received),
        String(t.investorCount),
        String(t.averageInvestment),
      ]),
    ];
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
    downloadCsv(`venture-floor-${stamp}.csv`, rows);
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:justify-end">
        <Button type="button" variant="outline" onClick={exportCsv}>
          <Download />
          Download CSV
        </Button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button type="button" variant="destructive">
              Clear votes
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Clear this round?</AlertDialogTitle>
              <AlertDialogDescription>
                Every envelope is deleted. Team names and codes stay. This cannot
                be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Keep votes</AlertDialogCancel>
              <AlertDialogAction onClick={() => clearMut.mutate()}>
                Clear votes
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      <Card className="rounded-2xl">
        <CardHeader>
          <CardTitle>Who has voted</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="grid gap-2 sm:grid-cols-2">
            {state.teams.map((team) => (
              <li
                key={team.id}
                className="flex items-center justify-between rounded-md bg-muted/60 px-3 py-2 text-sm"
              >
                <span>{team.name}</span>
                <span className="text-muted-foreground">
                  {team.submitted ? isoToLocal(team.submittedAt) : "Waiting"}
                </span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <div className="overflow-x-auto rounded-2xl bg-card shadow-border">
        <table className="w-full min-w-[36rem] text-left text-sm">
          <thead className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
            <tr>
              <th className="px-4 py-3 font-medium">From</th>
              <th className="px-4 py-3 font-medium">To</th>
              <th className="px-4 py-3 font-medium">Amount</th>
              <th className="px-4 py-3 font-medium">When</th>
            </tr>
          </thead>
          <tbody>
            {state.votes.length === 0 ? (
              <tr>
                <td className="px-4 py-6 text-muted-foreground" colSpan={4}>
                  No envelopes yet.
                </td>
              </tr>
            ) : (
              state.votes.map((vote, index) => (
                <tr key={`${vote.fromTeamId}-${vote.toTeamId}-${index}`} className="border-t border-border">
                  <td className="px-4 py-3">{vote.fromTeam}</td>
                  <td className="px-4 py-3">{vote.toTeam}</td>
                  <td className="px-4 py-3 tabular-nums">{formatRupee(vote.amount)}</td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {isoToLocal(vote.timestamp)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="flex flex-col gap-2">
      <span className="text-sm font-medium">{label}</span>
      {children}
    </label>
  );
}

function toDatetimeLocal(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function errorMessage(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  return "Something went wrong.";
}
