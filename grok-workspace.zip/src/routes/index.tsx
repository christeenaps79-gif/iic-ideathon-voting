import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Landmark, MapPin, Timer } from "lucide-react";
import { SiteFooter, SiteHeader } from "@/components/site-header";
import { LiveDot } from "@/components/live-dot";
import { LeaderboardList } from "@/components/leaderboard-list";
import { Countdown } from "@/components/countdown";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { getPublicState } from "@/lib/ideathon/server";
import { formatInt, formatRupee } from "@/lib/ideathon/format";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const stateQuery = useQuery({
    queryKey: ["public-state"],
    queryFn: () => getPublicState(),
    refetchInterval: 4000,
  });
  const state = stateQuery.data;

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader live={state?.votingLive} />
      <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col px-4 pb-20 pt-10 sm:px-6 sm:pt-16">
        <section className="grid gap-10 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
          <div>
            <p className="text-xs uppercase tracking-[0.22em] text-muted-foreground">
              Institution Innovation Council
            </p>
            <h1 className="mt-4 max-w-xl font-display text-4xl leading-[1.05] tracking-tight sm:text-6xl">
              Back the idea, not the applause.
            </h1>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-muted-foreground sm:text-lg">
              Every team walks in with the same purse. After the pitches, you
              invest fake rupees in the work you would actually fund. The board
              tells the hall who convinced the room.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button asChild size="lg">
                <Link to="/vote">
                  Invest as a team
                  <ArrowRight />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/board">Open live board</Link>
              </Button>
            </div>
          </div>
          <Card className="rounded-2xl p-1">
            <CardContent className="rounded-xl bg-muted/50 p-5 sm:p-6">
              {stateQuery.isLoading || !state ? (
                <div className="flex flex-col gap-3">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-8 w-64" />
                  <Skeleton className="h-4 w-52" />
                </div>
              ) : (
                <>
                  <LiveDot live={state.votingLive} />
                  <h2 className="mt-4 font-display text-3xl tracking-tight">
                    {state.eventName}
                  </h2>
                  <dl className="mt-5 flex flex-col gap-3 text-sm">
                    <div className="flex items-start gap-3 text-muted-foreground">
                      <Timer className="mt-0.5 size-4 shrink-0" />
                      <span>{state.eventWhen}</span>
                    </div>
                    <div className="flex items-start gap-3 text-muted-foreground">
                      <MapPin className="mt-0.5 size-4 shrink-0" />
                      <span>{state.venue}</span>
                    </div>
                    <div className="flex items-start gap-3 text-muted-foreground">
                      <Landmark className="mt-0.5 size-4 shrink-0" />
                      <span>
                        Starting purse {formatRupee(state.initialAmount)} ·{" "}
                        {state.teamCount} teams
                      </span>
                    </div>
                  </dl>
                  {state.deadline ? (
                    <Countdown className="mt-6" deadline={state.deadline} />
                  ) : null}
                </>
              )}
            </CardContent>
          </Card>
        </section>

        <section className="mt-16 grid gap-4 sm:grid-cols-3">
          {[
            {
              step: "01",
              title: "Collect your code",
              body: "Organizers add teams before the floor opens. You sign in with the team name or the four-letter code.",
            },
            {
              step: "02",
              title: "Split the purse",
              body: "You cannot fund yourself. Spread the capital, leave a remainder, then lock it in — one submission each.",
            },
            {
              step: "03",
              title: "Watch the board",
              body: "Totals, investor counts, and the lead change as envelopes come in. Projector view lives on the Board.",
            },
          ].map((item) => (
            <Card key={item.step} className="rounded-2xl p-5 sm:p-6">
              <p className="text-xs tabular-nums uppercase tracking-[0.18em] text-muted-foreground">
                {item.step}
              </p>
              <h3 className="mt-3 font-display text-2xl tracking-tight">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {item.body}
              </p>
            </Card>
          ))}
        </section>

        <section className="mt-16 grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <h2 className="font-display text-3xl tracking-tight">On the tape</h2>
            <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
              Circulation is the sum of every purse. Invested is what has
              actually moved. Unspent capital stays with the team that held it.
            </p>
            {state ? (
              <dl className="mt-6 grid grid-cols-2 gap-4">
                <Stat label="In circulation" value={formatRupee(state.totalInCirculation)} />
                <Stat label="Moved" value={formatRupee(state.totalInvested)} />
                <Stat
                  label="Ballots in"
                  value={`${formatInt(state.submittedCount)} / ${formatInt(state.teamCount)}`}
                />
                <Stat
                  label="Participation"
                  value={
                    state.teamCount === 0
                      ? "—"
                      : `${Math.round((state.submittedCount / state.teamCount) * 100)}%`
                  }
                />
              </dl>
            ) : (
              <div className="mt-6 grid grid-cols-2 gap-4">
                <Skeleton className="h-24" />
                <Skeleton className="h-24" />
                <Skeleton className="h-24" />
                <Skeleton className="h-24" />
              </div>
            )}
          </div>
          <div>
            <div className="mb-4 flex items-end justify-between gap-3">
              <h2 className="font-display text-3xl tracking-tight">Live lead</h2>
              <Button asChild variant="link" className="h-auto p-0">
                <Link to="/board">Full board</Link>
              </Button>
            </div>
            {state ? (
              <LeaderboardList teams={state.leaderboard.slice(0, 5)} compact />
            ) : (
              <div className="flex flex-col gap-3">
                <Skeleton className="h-24" />
                <Skeleton className="h-24" />
                <Skeleton className="h-24" />
              </div>
            )}
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-card p-4 shadow-border">
      <dt className="text-xs uppercase tracking-[0.16em] text-muted-foreground">
        {label}
      </dt>
      <dd className="mt-2 font-display text-2xl tabular-nums tracking-tight">{value}</dd>
    </div>
  );
}
