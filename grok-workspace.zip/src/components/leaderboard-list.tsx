import { formatRupee } from "@/lib/ideathon/format";
import type { PublicTeam, TopInvestor } from "@/lib/ideathon/types";
import { cn } from "@/lib/utils";

export function LeaderboardList({
  teams,
  topInvestors,
  compact = false,
}: {
  teams: PublicTeam[];
  topInvestors?: Record<number, TopInvestor[]>;
  compact?: boolean;
}) {
  const max = Math.max(1, ...teams.map((t) => t.received));

  if (teams.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">
        Teams will appear here once the floor is set up.
      </p>
    );
  }

  return (
    <ol className="flex flex-col gap-3">
      {teams.map((team) => {
        const width = Math.max(4, Math.round((team.received / max) * 100));
        const investors = topInvestors?.[team.id] ?? [];
        return (
          <li key={team.id} className="rounded-lg bg-muted/60 p-4">
            <div className="flex items-baseline justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs tabular-nums text-muted-foreground">
                  {String(team.rank).padStart(2, "0")}
                </p>
                <h3 className="truncate font-display text-lg tracking-tight">
                  {team.name}
                </h3>
                {!compact && team.pitch ? (
                  <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">
                    {team.pitch}
                  </p>
                ) : null}
              </div>
              <p className="shrink-0 font-display text-xl tabular-nums tracking-tight">
                {formatRupee(team.received)}
              </p>
            </div>
            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-background">
              <div
                className={cn(
                  "h-full rounded-full bg-accent transition-[width] duration-[var(--motion-slow)] ease-[var(--ease-smooth-out)]",
                )}
                style={{ width: `${width}%` }}
              />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {team.investorCount} {team.investorCount === 1 ? "investor" : "investors"}
              {team.investorCount > 0
                ? ` · avg ${formatRupee(team.averageInvestment)}`
                : ""}
            </p>
            {investors.length > 0 ? (
              <ul className="mt-3 flex flex-col gap-1 text-xs text-muted-foreground">
                {investors.map((inv) => (
                  <li key={inv.fromTeam} className="flex justify-between gap-3">
                    <span className="truncate">{inv.fromTeam}</span>
                    <span className="tabular-nums text-foreground">
                      {formatRupee(inv.amount)}
                    </span>
                  </li>
                ))}
              </ul>
            ) : null}
          </li>
        );
      })}
    </ol>
  );
}
