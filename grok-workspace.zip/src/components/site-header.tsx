import { Link, useRouterState } from "@tanstack/react-router";
import { LiveDot } from "@/components/live-dot";
import { cn } from "@/lib/utils";

const links = [
  { to: "/", label: "Home" },
  { to: "/vote", label: "Invest" },
  { to: "/board", label: "Board" },
  { to: "/admin", label: "Organizers" },
] as const;

export function SiteHeader({
  live,
  dense = false,
}: {
  live?: boolean;
  dense?: boolean;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header
      className={cn(
        "sticky top-0 z-40 border-b border-border/80 bg-background/90 backdrop-blur-md",
        dense ? "px-4 py-3" : "px-4 py-4 sm:px-6",
      )}
    >
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4">
        <Link to="/" className="group min-w-0">
          <p className="font-display text-lg leading-none tracking-tight sm:text-xl">
            Venture Floor
          </p>
          <p className="mt-1 truncate text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            IIC Ideathon · CEA
          </p>
        </Link>
        <nav className="flex items-center gap-1 sm:gap-2">
          {typeof live === "boolean" ? (
            <span className="mr-2 hidden sm:inline-flex">
              <LiveDot live={live} />
            </span>
          ) : null}
          {links.map((link) => {
            const active =
              link.to === "/"
                ? pathname === "/"
                : pathname === link.to || pathname.startsWith(`${link.to}/`);
            return (
              <Link
                key={link.to}
                to={link.to}
                className={cn(
                  "rounded-md px-2.5 py-2 text-sm transition-colors duration-[var(--motion-quick)] sm:px-3",
                  active
                    ? "bg-muted text-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-border/80 px-4 py-8">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
        <p>College of Engineering Adoor · Institution Innovation Council</p>
        <p>Fake capital. Real conviction.</p>
      </div>
    </footer>
  );
}
