import { cn } from "@/lib/utils";

export function LiveDot({
  live,
  label,
}: {
  live: boolean;
  label?: string;
}) {
  return (
    <span className="inline-flex items-center gap-2 text-xs font-medium tracking-wide uppercase">
      <span
        className={cn(
          "relative size-2 rounded-full",
          live ? "bg-success" : "bg-muted-foreground/50",
        )}
      >
        {live ? (
          <span className="absolute inset-0 animate-ping rounded-full bg-success/70" />
        ) : null}
      </span>
      <span className={live ? "text-success" : "text-muted-foreground"}>
        {label ?? (live ? "Floor open" : "Floor closed")}
      </span>
    </span>
  );
}
