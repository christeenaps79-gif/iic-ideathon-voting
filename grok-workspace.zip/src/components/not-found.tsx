import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteHeader } from "@/components/site-header";

export function NotFound() {
  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main className="mx-auto flex w-full max-w-lg flex-1 flex-col justify-center px-4 py-16 text-center">
        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">404</p>
        <h1 className="mt-3 font-display text-4xl tracking-tight">Page not on the floor</h1>
        <p className="mt-3 text-muted-foreground">
          That route is not part of Venture Floor. Head back to the hall.
        </p>
        <div className="mt-8">
          <Button asChild>
            <Link to="/">Return home</Link>
          </Button>
        </div>
      </main>
    </div>
  );
}
