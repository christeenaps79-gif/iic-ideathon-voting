import { useEffect, useState } from "react";

function partsUntil(deadline: string, nowMs: number) {
  const end = new Date(deadline).getTime();
  const diff = Math.max(0, end - nowMs);
  const totalSeconds = Math.floor(diff / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return { hours, minutes, seconds, expired: diff <= 0 };
}

function pad(n: number) {
  return String(n).padStart(2, "0");
}

export function Countdown({
  deadline,
  className,
}: {
  deadline: string | null;
  className?: string;
}) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!deadline) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [deadline]);

  if (!deadline) return null;
  const { hours, minutes, seconds, expired } = partsUntil(deadline, now);

  return (
    <div className={className}>
      <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
        {expired ? "Deadline passed" : "Closes in"}
      </p>
      <p className="mt-1 font-display text-2xl tabular-nums tracking-tight text-foreground">
        {expired ? "00:00:00" : `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`}
      </p>
    </div>
  );
}
